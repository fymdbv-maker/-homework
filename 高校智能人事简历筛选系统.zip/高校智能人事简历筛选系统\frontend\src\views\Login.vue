<template>
  <div class="login-page">
    <div class="login-card">
      <div class="login-header">
        <h1>高校智能人事简历筛选系统</h1>
        <p>Resume Screening System for University HR</p>
      </div>
      <el-form :model="form" size="large" @keyup.enter="onLogin">
        <el-form-item>
          <el-input v-model="form.username" placeholder="用户名" :prefix-icon="User" />
        </el-form-item>
        <el-form-item>
          <el-input v-model="form.password" type="password" show-password placeholder="密码" :prefix-icon="Lock" />
        </el-form-item>
        <el-form-item>
          <el-button type="primary" style="width: 100%" :loading="loading" @click="onLogin">登 录</el-button>
        </el-form-item>
      </el-form>
      <el-divider content-position="center">演示账号</el-divider>
      <div class="demo-accounts">
        <el-tag v-for="a in demoAccounts" :key="a.u" class="demo-tag" @click="fill(a.u, a.p)">
          {{ a.label }}：{{ a.u }} / {{ a.p }}
        </el-tag>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { reactive, ref } from 'vue'
import { useRouter } from 'vue-router'
import { User, Lock } from '@element-plus/icons-vue'
import { ElMessage } from 'element-plus'
import api from '../api'

const router = useRouter()
const loading = ref(false)
const form = reactive({ username: 'admin', password: 'admin123' })

const demoAccounts = [
  { label: '管理员', u: 'admin', p: 'admin123' },
  { label: '人事专员', u: 'hr', p: 'hr123456' },
  { label: '只读用户', u: 'viewer', p: 'view123' },
]

function fill(u: string, p: string) {
  form.username = u
  form.password = p
}

async function onLogin() {
  if (!form.username || !form.password) {
    ElMessage.warning('请输入用户名和密码')
    return
  }
  loading.value = true
  try {
    const { data } = await api.post('/auth/login', form)
    localStorage.setItem('token', data.access_token)
    localStorage.setItem('user', JSON.stringify(data.user))
    ElMessage.success(`欢迎，${data.user.display_name || data.user.username}`)
    router.push('/dashboard')
  } catch {
    // 错误消息已由拦截器提示
  } finally {
    loading.value = false
  }
}
</script>

<style scoped>
.login-page {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background: linear-gradient(135deg, #001529 0%, #003a70 100%);
}
.login-card {
  width: 420px;
  background: #fff;
  border-radius: 12px;
  padding: 36px 40px 28px;
  box-shadow: 0 12px 40px rgba(0, 0, 0, 0.35);
}
.login-header { text-align: center; margin-bottom: 24px; }
.login-header h1 { font-size: 22px; color: #001529; margin: 0 0 6px; }
.login-header p { color: #909399; font-size: 13px; margin: 0; }
.demo-accounts { display: flex; flex-direction: column; gap: 8px; align-items: center; }
.demo-tag { cursor: pointer; }
</style>
