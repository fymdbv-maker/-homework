import hashlib
from pathlib import Path

from fastapi import APIRouter, Depends, File, HTTPException, Query, Request, UploadFile
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session

from ..config import settings
from ..database import get_db
from ..deps import audit, get_current_user
from ..models import ImportLog, Resume, User
from ..schemas import ResumeDetail, ResumeManualUpdate, ResumeOut, ScreeningResultOut
from ..services.resume_parser import extract_text, parse_fields

router = APIRouter(prefix="/api/resumes", tags=["resumes"])

ALLOWED_EXT = {".pdf", ".docx", ".doc", ".txt", ".jpg", ".jpeg", ".png", ".bmp", ".webp"}


def _process_resume(db: Session, resume: Resume):
    """Extract text + parse fields for a stored resume file."""
    text, note = extract_text(Path(resume.stored_path), resume.file_type)
    resume.raw_text = text
    fields, sources, notes = parse_fields(text)
    for k, v in fields.items():
        if hasattr(resume, k):
            setattr(resume, k, v)
    resume.field_sources = sources
    all_notes = [n for n in [note, *notes] if n]
    resume.parse_notes = "\n".join(all_notes)
    if not text:
        resume.parse_status = "failed" if note.startswith("文件解析失败") else "partial"
    elif all_notes:
        resume.parse_status = "partial"
    else:
        resume.parse_status = "parsed"


@router.get("", response_model=dict)
def list_resumes(
    page: int = Query(1, ge=1),
    page_size: int = Query(10, ge=1, le=100),
    keyword: str = "",
    education: str = "",
    is_fresh: str = "",
    parse_status: str = "",
    school_tier: str = "",
    source: str = "",
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    q = db.query(Resume)
    if keyword:
        like = f"%{keyword}%"
        q = q.filter(
            (Resume.name.like(like))
            | (Resume.school.like(like))
            | (Resume.major.like(like))
            | (Resume.target_position.like(like))
            | (Resume.filename.like(like))
        )
    if education:
        q = q.filter(Resume.education == education)
    if is_fresh:
        q = q.filter(Resume.is_fresh == is_fresh)
    if parse_status:
        q = q.filter(Resume.parse_status == parse_status)
    if school_tier:
        q = q.filter(Resume.school_tier == school_tier)
    if source:
        q = q.filter(Resume.source == source)
    total = q.count()
    rows = q.order_by(Resume.created_at.desc()).offset((page - 1) * page_size).limit(page_size).all()
    return {"total": total, "items": [ResumeOut.model_validate(r) for r in rows]}


@router.post("/upload", response_model=list[ResumeOut])
async def upload_resumes(
    request: Request,
    files: list[UploadFile] = File(...),
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    created: list[Resume] = []
    for f in files:
        ext = Path(f.filename or "").suffix.lower()
        if ext not in ALLOWED_EXT:
            raise HTTPException(400, f"不支持的文件类型: {f.filename}")
        data = await f.read()
        if not data:
            raise HTTPException(400, f"文件为空: {f.filename}")
        file_hash = hashlib.sha256(data).hexdigest()
        dup = db.query(Resume).filter(Resume.file_hash == file_hash).first()
        if dup:
            db.add(ImportLog(
                source="upload", reference=f.filename or "", attachment_name=f.filename or "",
                file_hash=file_hash, status="duplicate", detail=f"与简历 #{dup.id} 重复，已跳过",
            ))
            continue
        save_name = f"{file_hash[:16]}{ext}"
        dest = settings.UPLOAD_DIR / save_name
        dest.write_bytes(data)
        resume = Resume(
            filename=f.filename or save_name, stored_path=str(dest), file_type=ext,
            file_hash=file_hash, file_size=len(data), source="upload",
        )
        db.add(resume)
        db.flush()
        _process_resume(db, resume)
        db.add(ImportLog(
            source="upload", reference=f.filename or "", attachment_name=f.filename or "",
            file_hash=file_hash, status="success", detail=f"导入为简历 #{resume.id}",
        ))
        audit(db, user, "upload_resume", "resume", resume.id, f"上传 {f.filename}", request)
        created.append(resume)
    db.commit()
    return [ResumeOut.model_validate(r) for r in created]


@router.post("/{resume_id}/reparse", response_model=ResumeOut)
def reparse(resume_id: int, request: Request, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    resume = db.get(Resume, resume_id)
    if not resume:
        raise HTTPException(404, "简历不存在")
    _process_resume(db, resume)
    audit(db, user, "reparse_resume", "resume", resume.id, "重新解析", request)
    db.commit()
    return ResumeOut.model_validate(resume)


@router.get("/{resume_id}", response_model=ResumeDetail)
def get_resume(resume_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    resume = db.get(Resume, resume_id)
    if not resume:
        raise HTTPException(404, "简历不存在")
    detail = ResumeDetail.model_validate(resume)
    detail.results = [ScreeningResultOut.model_validate(r) for r in resume.results]
    return detail


@router.put("/{resume_id}", response_model=ResumeOut)
def update_resume(
    resume_id: int, body: ResumeManualUpdate, request: Request,
    db: Session = Depends(get_db), user: User = Depends(get_current_user),
):
    resume = db.get(Resume, resume_id)
    if not resume:
        raise HTTPException(404, "简历不存在")
    changed = []
    for k, v in body.model_dump(exclude_unset=True).items():
        if v is not None and hasattr(resume, k):
            setattr(resume, k, v)
            changed.append(k)
    audit(db, user, "update_resume", "resume", resume.id, "人工修正字段: " + ",".join(changed), request)
    db.commit()
    return ResumeOut.model_validate(resume)


@router.delete("/{resume_id}")
def delete_resume(resume_id: int, request: Request, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    resume = db.get(Resume, resume_id)
    if not resume:
        raise HTTPException(404, "简历不存在")
    path = Path(resume.stored_path)
    audit(db, user, "delete_resume", "resume", resume.id, f"删除 {resume.filename}", request)
    db.delete(resume)
    db.commit()
    if path.exists():
        try:
            path.unlink()
        except OSError:
            pass
    return {"ok": True}


@router.get("/{resume_id}/file")
def get_file(resume_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """Access-controlled download of the original file (requires login)."""
    resume = db.get(Resume, resume_id)
    if not resume:
        raise HTTPException(404, "简历不存在")
    path = Path(resume.stored_path)
    if not path.exists():
        raise HTTPException(404, "原始文件已丢失")
    return FileResponse(str(path), filename=resume.filename)
