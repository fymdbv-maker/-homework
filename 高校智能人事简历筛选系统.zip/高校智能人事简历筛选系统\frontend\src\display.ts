/** 共享显示映射 — 空值统一显示“待核实” */
export const UNKNOWN = '待核实'

export function show(v: string | number | null | undefined): string {
  if (v === null || v === undefined || v === '') return UNKNOWN
  return String(v)
}

export const educationOptions = ['博士', '硕士', '本科', '大专', '其他']
export const schoolTierOptions = ['985', '211', '双一流', '普通本科', '其他']

export const freshMap: Record<string, { label: string; type: string }> = {
  fresh: { label: '应届毕业生', type: 'success' },
  not_fresh: { label: '非应届', type: 'info' },
  unknown: { label: UNKNOWN, type: 'warning' },
}

export const qualMap: Record<string, { label: string; type: string }> = {
  qualified: { label: '符合条件', type: 'success' },
  unqualified: { label: '不符合条件', type: 'danger' },
  needs_review: { label: '待人工核实', type: 'warning' },
}

export const reviewStatusMap: Record<string, { label: string; type: string }> = {
  pending: { label: '待审核', type: 'warning' },
  approved: { label: '已通过', type: 'success' },
  rejected: { label: '未通过', type: 'danger' },
}

export const parseStatusMap: Record<string, { label: string; type: string }> = {
  pending: { label: '待解析', type: 'info' },
  parsed: { label: '解析成功', type: 'success' },
  partial: { label: '部分识别', type: 'warning' },
  failed: { label: '解析失败', type: 'danger' },
}

export const permitMap: Record<string, string> = {
  valid: '有效上海居住证',
  none: '无',
  unknown: UNKNOWN,
}

export const checkStatusMap: Record<string, { label: string; type: string }> = {
  pass: { label: '满足', type: 'success' },
  fail: { label: '不满足', type: 'danger' },
  unknown: { label: '待核实', type: 'warning' },
}
