"""SQLAlchemy models for the HR resume screening system."""
from datetime import datetime

from sqlalchemy import JSON, Boolean, Column, DateTime, Float, ForeignKey, Integer, String, Text
from sqlalchemy.orm import relationship

from .database import Base


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True)
    username = Column(String(64), unique=True, nullable=False, index=True)
    password_hash = Column(String(255), nullable=False)
    display_name = Column(String(64), nullable=False, default="")
    role = Column(String(32), nullable=False, default="hr")  # admin / hr / viewer
    active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)


class Position(Base):
    __tablename__ = "positions"

    id = Column(Integer, primary_key=True)
    name = Column(String(128), nullable=False)
    code = Column(String(64), unique=True, nullable=False)
    department = Column(String(128), default="")
    description = Column(Text, default="")
    active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    rules = relationship("Rule", back_populates="position")


class Rule(Base):
    """Screening rule attached to a position. `config` holds structured conditions.

    config example:
    {
      "min_education": "硕士",                    # 博士/硕士/本科/大专
      "accepted_majors": ["教育学", "心理学"],
      "major_match_required": false,
      "max_age": 40,                              # null = no limit
      "require_party_member": true,               # 辅导员岗位
      "non_fresh_requires": "shanghai_hukou_or_residence_permit",  # or null
      "fresh_only": false,
      "min_work_years": 0,
      "scoring": {
         "school_tier": {"985": 20, "211": 15, "双一流": 12, "普通本科": 8, "其他": 4},
         "education": {"博士": 25, "硕士": 18, "本科": 10, "大专": 4},
         "major_match": 20,
         "fresh_bonus": 10,
         "work_years": {"per_year": 2, "max": 15},
         "related_experience_bonus": 10
      }
    }
    """
    __tablename__ = "rules"

    id = Column(Integer, primary_key=True)
    position_id = Column(Integer, ForeignKey("positions.id"), nullable=False)
    name = Column(String(128), nullable=False)
    version = Column(Integer, nullable=False, default=1)
    config = Column(JSON, nullable=False, default=dict)
    enabled = Column(Boolean, default=True)
    created_by = Column(String(64), default="")
    change_note = Column(String(255), default="")
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    position = relationship("Position", back_populates="rules")


class Resume(Base):
    __tablename__ = "resumes"

    id = Column(Integer, primary_key=True)
    filename = Column(String(255), nullable=False)
    stored_path = Column(String(512), nullable=False)
    file_type = Column(String(16), nullable=False, default="")
    file_hash = Column(String(64), nullable=False, index=True)
    file_size = Column(Integer, default=0)
    source = Column(String(16), nullable=False, default="upload")  # upload / email

    # extracted fields — empty string means 待核实 (unknown), never fabricated
    name = Column(String(64), default="")
    gender = Column(String(8), default="")
    target_position = Column(String(128), default="")
    education = Column(String(32), default="")        # 博士/硕士/本科/大专/其他
    degree = Column(String(64), default="")
    school = Column(String(128), default="")
    school_tier = Column(String(32), default="")      # 985/211/双一流/普通本科/其他
    major = Column(String(128), default="")
    graduation_date = Column(String(32), default="")
    work_years = Column(Float, nullable=True)          # null = unknown
    is_fresh = Column(String(16), default="unknown")   # fresh / not_fresh / unknown
    birth_date = Column(String(32), default="")
    age = Column(Integer, nullable=True)
    political_status = Column(String(32), default="")
    hukou = Column(String(64), default="")
    shanghai_residence_permit = Column(String(16), default="unknown")  # valid / none / unknown
    phone = Column(String(32), default="")
    email = Column(String(128), default="")

    parse_status = Column(String(16), default="pending")  # pending/parsed/partial/failed
    parse_notes = Column(Text, default="")
    raw_text = Column(Text, default="")
    field_sources = Column(JSON, default=dict)  # field -> evidence snippet
    created_at = Column(DateTime, default=datetime.utcnow)

    results = relationship("ScreeningResult", back_populates="resume", cascade="all, delete-orphan")


class ScreeningResult(Base):
    __tablename__ = "screening_results"

    id = Column(Integer, primary_key=True)
    resume_id = Column(Integer, ForeignKey("resumes.id"), nullable=False)
    rule_id = Column(Integer, ForeignKey("rules.id"), nullable=False)
    rule_version = Column(Integer, nullable=False)
    position_name = Column(String(128), default="")

    hard_checks = Column(JSON, default=list)       # [{item, requirement, status, evidence}]
    qualification = Column(String(16), default="needs_review")  # qualified / unqualified / needs_review
    score = Column(Float, default=0)
    score_breakdown = Column(JSON, default=list)   # [{item, points, max, reason}]
    suggestion = Column(Text, default="")           # AI-assisted, advisory only

    status = Column(String(16), default="pending")  # pending / approved / rejected
    reviewer = Column(String(64), default="")
    review_note = Column(Text, default="")
    reviewed_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    resume = relationship("Resume", back_populates="results")
    rule = relationship("Rule")


class EmailConfig(Base):
    __tablename__ = "email_configs"

    id = Column(Integer, primary_key=True)
    host = Column(String(255), default="")
    port = Column(Integer, default=993)
    username = Column(String(255), default="")
    password_enc = Column(String(512), default="")  # Fernet-encrypted
    use_ssl = Column(Boolean, default=True)
    enabled = Column(Boolean, default=False)
    last_sync_at = Column(DateTime, nullable=True)
    last_sync_status = Column(String(32), default="")
    last_sync_message = Column(Text, default="")


class ImportLog(Base):
    __tablename__ = "import_logs"

    id = Column(Integer, primary_key=True)
    source = Column(String(16), nullable=False, default="email")  # email / upload
    reference = Column(String(255), default="")       # email message-id or subject
    attachment_name = Column(String(255), default="")
    file_hash = Column(String(64), default="")
    status = Column(String(16), nullable=False)        # success / duplicate / failed
    detail = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.utcnow)


class AuditLog(Base):
    __tablename__ = "audit_logs"

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, nullable=True)
    username = Column(String(64), default="")
    action = Column(String(64), nullable=False)
    target_type = Column(String(64), default="")
    target_id = Column(String(64), default="")
    detail = Column(Text, default="")
    ip = Column(String(64), default="")
    created_at = Column(DateTime, default=datetime.utcnow)


class SystemSetting(Base):
    __tablename__ = "system_settings"

    key = Column(String(64), primary_key=True)
    value = Column(Text, default="")
    description = Column(String(255), default="")
