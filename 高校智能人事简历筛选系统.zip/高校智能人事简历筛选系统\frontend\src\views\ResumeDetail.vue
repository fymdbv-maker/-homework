<template>
  <div v-loading="loading">
    <el-card shadow="never" v-if="detail">
      <template #header>
        <div class="header">
          <div>
            <span class="title">{{ show(detail.name) }}</span>
            <el-tag size="small" style="margin-left: 8px" :type="parseStatusMap[detail.parse_status]?.type">
              {{ parseStatusMap[detail.parse_status]?.label }}
            </el-tag>
          </div>
          <div>
            <el-button size="small" @click="downloadFile">下载原始文件</el-button>
            <el-button size="small" type="warning" @click="reparse" :loading="reparsing">重新解析</el-button>
            <el-button size="small" type="primary" @click="editDialog = true">人工修正</el-button>
          </div>
        </div>
      </template>

      <el-alert v-if="detail.parse_notes" type="warning" :closable="false" style="margin-bottom: 12px">
        <template #title>解析备注：{{ detail.parse_notes }}</template>
      </el-alert>

      <el-descriptions :column="3" border size="small">
        <el-descriptions-item label="姓名">{{ show(detail.name) }}</el-descriptions-item>
        <el-descriptions-item label="性别">{{ show(detail.gender) }}</el-descriptions-item>
        <el-descriptions-item label="应聘岗位">{{ show(detail.target_position) }}</el-descriptions-item>
        <el-descriptions-item label="最高学历">{{ show(detail.education) }}</el-descriptions-item>
        <el-descriptions-item label="毕业院校">{{ show(detail.school) }} <el-tag v-if="detail.school_tier" size="small">{{ detail.school_tier }}</el-tag></el-descriptions-item>
        <el-descriptions-item label="专业">{{ show(detail.major) }}</el-descriptions-item>
        <el-descriptions-item label="毕业时间">{{ show(detail.graduation_date) }}</el-descriptions-item>
        <el-descriptions-item label="工作经验">{{ detail.work_years === null ? UNKNOWN : detail.work_years + ' 年' }}</el-descriptions-item>
        <el-descriptions-item label="应届身份"><el-tag size="small" :type="freshMap[detail.is_fresh]?.type">{{ freshMap[detail.is_fresh]?.label }}</el-tag></el-descriptions-item>
        <el-descriptions-item label="出生日期">{{ show(detail.birth_date) }}</el-descriptions-item>
        <el-descriptions-item label="年龄">{{ detail.age === null ? UNKNOWN : detail.age + ' 岁' }}</el-descriptions-item>
        <el-descriptions-item label="政治面貌">{{ show(detail.political_status) }}</el-descriptions-item>
        <el-descriptions-item label="户籍">{{ show(detail.hukou) }}</el-descriptions-item>
        <el-descriptions-item label="上海居住证">{{ permitMap[detail.shanghai_residence_permit] || UNKNOWN }}</el-descriptions-item>
        <el-descriptions-item label="电话">{{ show(detail.phone) }}</el-descriptions-item>
        <el-descriptions-item label="邮箱">{{ show(detail.email) }}</el-descriptions-item>
        <el-descriptions-item label="来源文件名">{{ detail.filename }}</el-descriptions-item>
      </el-descriptions>

      <el-collapse style="margin-top: 12px">
        <el-collapse-item title="字段识别依据（证据来源）" name="evidence">
          <el-table :data="evidenceRows" size="small">
            <el-table-column prop="field" label="字段" width="140" />
            <el-table-column prop="evidence" label="原文证据" show-overflow-tooltip />
          </el-table>
        </el-collapse-item>
        <el-collapse-item title="解析出的原始文本" name="raw">
          <pre class="raw-text">{{ detail.raw_text || '（无文本内容）' }}</pre>
        </el-collapse-item>
      </el-collapse>
    </el-card>

    <el-card shadow="never" style="margin-top: 16px" v-if="detail">
      <template #header><span class="title">筛选结果与人工审核</span></template>
      <el-empty v-if="!detail.results.length" description="尚未参与筛选，请前往“智能筛选”页面运行筛选" />
      <el-table v-else :data="detail.results" size="small">
        <el-table-column prop="position_name" label="岗位" width="120" />
        <el-table-column label="规则版本" width="90"><template #default="{ row }">v{{ row.rule_version }}</template></el-table-column>
        <el-table-column label="硬性核验" width="110">
          <template #default="{ row }"><el-tag size="small" :type="qualMap[row.qualification]?.type">{{ qualMap[row.qualification]?.label }}</el-tag></template>
        </el-table-column>
        <el-table-column prop="score" label="综合评分" width="90" />
        <el-table-column label="审核状态" width="90">
          <template #default="{ row }"><el-tag size="small" :type="reviewStatusMap[row.status]?.type">{{ reviewStatusMap[row.status]?.label }}</el-tag></template>
        </el-table-column>
        <el-table-column prop="reviewer" label="审核人" width="90"><template #default="{ row }">{{ row.reviewer || '—' }}</template></el-table-column>
        <el-table-column prop="suggestion" label="AI 辅助建议" show-overflow-tooltip />
        <el-table-column label="操作" width="90">
          <template #default="{ row }"><el-button text type="primary" size="small" @click="openChecks(row)">核验明细</el-button></template>
        </el-table-column>
      </el-table>
    </el-card>

    <el-dialog v-model="editDialog" title="人工修正简历字段" width="720px">
      <el-form :model="editForm" label-width="100px" size="small">
        <el-row :gutter="12">
          <el-col :span="8"><el-form-item label="姓名"><el-input v-model="editForm.name" /></el-form-item></el-col>
          <el-col :span="8"><el-form-item label="性别"><el-select v-model="editForm.gender" clearable><el-option label="男" value="男" /><el-option label="女" value="女" /></el-select></el-form-item></el-col>
          <el-col :span="8"><el-form-item label="应聘岗位"><el-input v-model="editForm.target_position" /></el-form-item></el-col>
          <el-col :span="8"><el-form-item label="最高学历"><el-select v-model="editForm.education" clearable><el-option v-for="e in educationOptions" :key="e" :label="e" :value="e" /></el-select></el-form-item></el-col>
          <el-col :span="8"><el-form-item label="毕业院校"><el-input v-model="editForm.school" /></el-form-item></el-col>
          <el-col :span="8"><el-form-item label="学校层次"><el-select v-model="editForm.school_tier" clearable><el-option v-for="t in schoolTierOptions" :key="t" :label="t" :value="t" /></el-select></el-form-item></el-col>
          <el-col :span="8"><el-form-item label="专业"><el-input v-model="editForm.major" /></el-form-item></el-col>
          <el-col :span="8"><el-form-item label="毕业时间"><el-input v-model="editForm.graduation_date" placeholder="如 2024-06" /></el-form-item></el-col>
          <el-col :span="8"><el-form-item label="工作经验(年)"><el-input-number v-model="editForm.work_years" :min="0" :max="50" style="width: 100%" /></el-form-item></el-col>
          <el-col :span="8"><el-form-item label="应届身份"><el-select v-model="editForm.is_fresh" clearable><el-option label="应届毕业生" value="fresh" /><el-option label="非应届" value="not_fresh" /><el-option label="待核实" value="unknown" /></el-select></el-form-item></el-col>
          <el-col :span="8"><el-form-item label="出生日期"><el-input v-model="editForm.birth_date" placeholder="如 1990-01" /></el-form-item></el-col>
          <el-col :span="8"><el-form-item label="年龄"><el-input-number v-model="editForm.age" :min="16" :max="80" style="width: 100%" /></el-form-item></el-col>
          <el-col :span="8"><el-form-item label="政治面貌"><el-input v-model="editForm.political_status" /></el-form-item></el-col>
          <el-col :span="8"><el-form-item label="户籍"><el-input v-model="editForm.hukou" /></el-form-item></el-col>
          <el-col :span="8"><el-form-item label="上海居住证"><el-select v-model="editForm.shanghai_residence_permit" clearable><el-option label="有效" value="valid" /><el-option label="无" value="none" /><el-option label="待核实" value="unknown" /></el-select></el-form-item></el-col>
          <el-col :span="8"><el-form-item label="电话"><el-input v-model="editForm.phone" /></el-form-item></el-col>
          <el-col :span="8"><el-form-item label="邮箱"><el-input v-model="editForm.email" /></el-form-item></el-col>
        </el-row>
      </el-form>
      <template #footer>
        <el-button @click="editDialog = false">取消</el-button>
        <el-button type="primary" :loading="saving" @click="saveEdit">保存</el-button>
      </template>
    </el-dialog>

    <el-drawer v-model="checksDrawer" title="硬性核验与评分明细" size="520px">
      <template v-if="activeResult">
        <h4>硬性资格核验</h4>
        <el-table :data="activeResult.hard_checks" size="small">
          <el-table-column prop="item" label="核验项" width="100" />
          <el-table-column prop="requirement" label="要求" width="140" show-overflow-tooltip />
          <el-table-column label="结果" width="80">
            <template #default="{ row }"><el-tag size="small" :type="checkStatusMap[row.status]?.type">{{ checkStatusMap[row.status]?.label }}</el-tag></template>
          </el-table-column>
          <el-table-column prop="evidence" label="依据" show-overflow-tooltip />
        </el-table>
        <h4 style="margin-top: 16px">综合评分（与硬性核验独立）</h4>
        <el-table :data="activeResult.score_breakdown" size="small">
          <el-table-column prop="item" label="评分项" width="120" />
          <el-table-column prop="points" label="得分" width="70" />
          <el-table-column prop="max" label="满分" width="70" />
          <el-table-column prop="reason" label="说明" show-overflow-tooltip />
        </el-table>
        <el-alert style="margin-top: 12px" type="info" :closable="false" :title="'AI 辅助建议：' + (activeResult.suggestion || '无')" />
      </template>
    </el-drawer>
  </div>
</template>

<script setup lang="ts">
import { computed, onMounted, reactive, ref, watch } from 'vue'
import { useRoute } from 'vue-router'
import { ElMessage } from 'element-plus'
import api from '../api'
import { show, UNKNOWN, educationOptions, schoolTierOptions, freshMap, parseStatusMap, permitMap, qualMap, reviewStatusMap, checkStatusMap } from '../display'

const route = useRoute()
const id = Number(route.params.id)
const loading = ref(false)
const detail = ref<any>(null)
const editDialog = ref(false)
const saving = ref(false)
const reparsing = ref(false)
const checksDrawer = ref(false)
const activeResult = ref<any>(null)
const editForm = reactive<any>({})

const fieldLabels: Record<string, string> = {
  name: '姓名', gender: '性别', target_position: '应聘岗位', education: '最高学历', school: '毕业院校',
  school_tier: '学校层次', major: '专业', graduation_date: '毕业时间', work_years: '工作经验',
  is_fresh: '应届身份', birth_date: '出生日期', political_status: '政治面貌', hukou: '户籍',
  shanghai_residence_permit: '上海居住证', phone: '电话', email: '邮箱',
}
const evidenceRows = computed(() =>
  Object.entries(detail.value?.field_sources || {}).map(([k, v]) => ({ field: fieldLabels[k] || k, evidence: v }))
)

async function load() {
  loading.value = true
  try {
    const { data } = await api.get(`/resumes/${id}`)
    detail.value = data
  } finally {
    loading.value = false
  }
}

function openEdit() {
  Object.assign(editForm, {
    name: detail.value.name, gender: detail.value.gender, target_position: detail.value.target_position,
    education: detail.value.education, school: detail.value.school, school_tier: detail.value.school_tier,
    major: detail.value.major, graduation_date: detail.value.graduation_date, work_years: detail.value.work_years,
    is_fresh: detail.value.is_fresh, birth_date: detail.value.birth_date, age: detail.value.age,
    political_status: detail.value.political_status, hukou: detail.value.hukou,
    shanghai_residence_permit: detail.value.shanghai_residence_permit, phone: detail.value.phone, email: detail.value.email,
  })
}

async function saveEdit() {
  saving.value = true
  try {
    await api.put(`/resumes/${id}`, editForm)
    ElMessage.success('已保存人工修正')
    editDialog.value = false
    load()
  } finally {
    saving.value = false
  }
}

async function reparse() {
  reparsing.value = true
  try {
    await api.post(`/resumes/${id}/reparse`)
    ElMessage.success('重新解析完成')
    load()
  } finally {
    reparsing.value = false
  }
}

async function downloadFile() {
  const { data } = await api.get(`/resumes/${id}/file`, { responseType: 'blob' })
  const url = URL.createObjectURL(data)
  const a = document.createElement('a')
  a.href = url
  a.download = detail.value.filename
  a.click()
  URL.revokeObjectURL(url)
}

function openChecks(row: any) {
  activeResult.value = row
  checksDrawer.value = true
}

watch(editDialog, (v) => { if (v && detail.value) openEdit() })
onMounted(load)
</script>

<style scoped>
.header { display: flex; justify-content: space-between; align-items: center; }
.title { font-size: 16px; font-weight: 600; }
.raw-text { white-space: pre-wrap; word-break: break-all; max-height: 320px; overflow-y: auto; background: #f7f8fa; padding: 12px; border-radius: 6px; font-size: 12px; }
</style>
