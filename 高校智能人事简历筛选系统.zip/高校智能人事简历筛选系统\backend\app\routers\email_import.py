from datetime import datetime

from fastapi import APIRouter, Depends, Query, Request
from sqlalchemy.orm import Session

from ..config import settings
from ..database import get_db
from ..deps import audit, get_current_user, require_role
from ..models import EmailConfig, ImportLog, User
from ..schemas import EmailConfigIn, EmailConfigOut, ImportLogOut
from ..security import encrypt_secret
from ..services import email_service

router = APIRouter(prefix="/api/email", tags=["email"])


@router.get("/config", response_model=EmailConfigOut)
def get_config(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    cfg = db.query(EmailConfig).first()
    env_configured = bool(settings.IMAP_HOST and settings.IMAP_USER)
    out = EmailConfigOut()
    if cfg:
        out = EmailConfigOut(
            id=cfg.id, host=cfg.host, port=cfg.port, username=cfg.username,
            has_password=bool(cfg.password_enc), use_ssl=cfg.use_ssl, enabled=cfg.enabled,
            configured=bool(cfg.host and cfg.username and (cfg.password_enc or env_configured)),
            demo_mode=False if (cfg.enabled and cfg.host and cfg.username and cfg.password_enc) else True,
            last_sync_at=cfg.last_sync_at, last_sync_status=cfg.last_sync_status,
            last_sync_message=cfg.last_sync_message,
        )
    elif env_configured:
        out = EmailConfigOut(
            host=settings.IMAP_HOST, port=settings.IMAP_PORT, username=settings.IMAP_USER,
            has_password=True, use_ssl=settings.IMAP_SSL, enabled=True,
            configured=True, demo_mode=False,
        )
    return out


@router.put("/config", response_model=EmailConfigOut)
def save_config(
    body: EmailConfigIn, request: Request,
    db: Session = Depends(get_db), user: User = Depends(require_role("admin")),
):
    cfg = db.query(EmailConfig).first()
    if not cfg:
        cfg = EmailConfig()
        db.add(cfg)
    cfg.host = body.host.strip()
    cfg.port = body.port
    cfg.username = body.username.strip()
    if body.password:  # empty keeps existing
        cfg.password_enc = encrypt_secret(body.password)
    cfg.use_ssl = body.use_ssl
    cfg.enabled = body.enabled
    audit(db, user, "save_email_config", "email_config", cfg.id or "", "更新邮箱配置", request)
    db.commit()
    return get_config(db, user)


@router.post("/sync")
def sync(
    request: Request,
    limit: int = Query(50, ge=1, le=200),
    db: Session = Depends(get_db), user: User = Depends(require_role("admin", "hr")),
):
    cfg = db.query(EmailConfig).first()
    try:
        stats = email_service.sync_email(db, limit=limit)
    except Exception as exc:  # noqa: BLE001
        if cfg:
            cfg.last_sync_at = datetime.utcnow()
            cfg.last_sync_status = "failed"
            cfg.last_sync_message = str(exc)[:500]
            db.commit()
        return {"ok": False, "demo_mode": True, "message": f"同步失败：{exc}", "stats": None}
    if cfg:
        cfg.last_sync_at = datetime.utcnow()
        cfg.last_sync_status = "success"
        cfg.last_sync_message = str(stats)
        db.commit()
    audit(db, user, "email_sync", "email_config", "", str(stats), request)
    db.commit()
    return {"ok": True, "demo_mode": False, "message": "同步完成", "stats": stats}


@router.get("/logs", response_model=dict)
def logs(
    page: int = Query(1, ge=1), page_size: int = Query(20, ge=1, le=100),
    db: Session = Depends(get_db), user: User = Depends(get_current_user),
):
    q = db.query(ImportLog).order_by(ImportLog.created_at.desc())
    total = q.count()
    rows = q.offset((page - 1) * page_size).limit(page_size).all()
    return {"total": total, "items": [ImportLogOut.model_validate(r) for r in rows]}
