from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .database import Base, engine
from .routers import auth, dashboard, email_import, resumes, rules, screening, system

Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="高校智能人事简历筛选系统",
    description="简历解析、岗位规则核验与辅助评分 API。AI 仅提供建议，不构成录用决定。",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router)
app.include_router(dashboard.router)
app.include_router(resumes.router)
app.include_router(screening.router)
app.include_router(rules.router)
app.include_router(email_import.router)
app.include_router(system.router)


@app.get("/api/health")
def health():
    return {"status": "ok"}
