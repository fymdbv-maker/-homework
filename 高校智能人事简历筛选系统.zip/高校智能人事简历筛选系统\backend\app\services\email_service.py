"""IMAP email import service. Stdlib imaplib; no real connection unless configured."""
import hashlib
import imaplib
import email
from email.header import decode_header
from email.message import Message
from pathlib import Path

from sqlalchemy.orm import Session

from ..config import settings
from ..models import EmailConfig, ImportLog, Resume
from ..security import decrypt_secret

ALLOWED_EXT = {".pdf", ".docx", ".doc", ".txt", ".jpg", ".jpeg", ".png", ".bmp", ".webp"}


def get_effective_config(db: Session) -> dict | None:
    """UI config takes precedence, then environment variables. None if not configured."""
    cfg = db.query(EmailConfig).first()
    if cfg and cfg.enabled and cfg.host and cfg.username:
        return {
            "host": cfg.host,
            "port": cfg.port or 993,
            "username": cfg.username,
            "password": decrypt_secret(cfg.password_enc),
            "use_ssl": bool(cfg.use_ssl),
            "source": "database",
        }
    if settings.IMAP_HOST and settings.IMAP_USER and settings.IMAP_PASSWORD:
        return {
            "host": settings.IMAP_HOST,
            "port": settings.IMAP_PORT,
            "username": settings.IMAP_USER,
            "password": settings.IMAP_PASSWORD,
            "use_ssl": settings.IMAP_SSL,
            "source": "env",
        }
    return None


def _decode_str(s: str | bytes | None) -> str:
    if s is None:
        return ""
    if isinstance(s, bytes):
        for enc in ("utf-8", "gb18030", "latin-1"):
            try:
                return s.decode(enc)
            except Exception:
                continue
        return s.decode("utf-8", errors="ignore")
    parts = decode_header(s)
    out = []
    for txt, enc in parts:
        if isinstance(txt, bytes):
            try:
                out.append(txt.decode(enc or "utf-8", errors="ignore"))
            except Exception:
                out.append(txt.decode("utf-8", errors="ignore"))
        else:
            out.append(txt)
    return "".join(out)


def _save_attachment(db: Session, part: Message, reference: str) -> str:
    """Persist attachment, create Resume row. Returns status string."""
    filename = _decode_str(part.get_filename())
    if not filename:
        return "skipped"
    ext = Path(filename).suffix.lower()
    if ext not in ALLOWED_EXT:
        return "skipped"
    payload = part.get_payload(decode=True) or b""
    if not payload:
        return "failed"
    file_hash = hashlib.sha256(payload).hexdigest()

    # duplicate detection: same hash already imported
    dup = db.query(Resume).filter(Resume.file_hash == file_hash).first()
    log = ImportLog(
        source="email", reference=reference[:250], attachment_name=filename[:250],
        file_hash=file_hash, status="success", detail="",
    )
    if dup:
        log.status = "duplicate"
        log.detail = f"与简历 #{dup.id} 内容相同，已跳过"
        db.add(log)
        return "duplicate"

    save_name = f"{file_hash[:16]}{ext}"
    dest = settings.UPLOAD_DIR / save_name
    dest.write_bytes(payload)

    resume = Resume(
        filename=filename, stored_path=str(dest), file_type=ext,
        file_hash=file_hash, file_size=len(payload), source="email",
        parse_status="pending",
    )
    db.add(resume)
    db.flush()
    log.detail = f"已导入为简历 #{resume.id}"
    db.add(log)
    return "success"


def sync_email(db: Session, limit: int = 50) -> dict:
    """Connect to IMAP and import resume attachments. Raises on connection failure."""
    cfg = get_effective_config(db)
    if not cfg:
        raise RuntimeError("未配置邮箱：请在页面或环境变量中设置 IMAP 参数")

    if cfg["use_ssl"]:
        conn = imaplib.IMAP4_SSL(cfg["host"], cfg["port"], timeout=30)
    else:
        conn = imaplib.IMAP4(cfg["host"], cfg["port"], timeout=30)
    try:
        conn.login(cfg["username"], cfg["password"])
        conn.select("INBOX")
        _, data = conn.search(None, "ALL")
        ids = (data[0] or b"").split()[-limit:]
        stats = {"processed": 0, "success": 0, "duplicate": 0, "skipped": 0, "failed": 0}
        for mid in reversed(ids):
            _, msg_data = conn.fetch(mid, "(RFC822)")
            raw = msg_data[0][1] if msg_data and msg_data[0] else b""
            if not raw:
                continue
            msg = email.message_from_bytes(raw)
            subject = _decode_str(msg.get("Subject"))
            for part in msg.walk():
                if part.get_content_disposition() != "attachment":
                    continue
                stats["processed"] += 1
                result = _save_attachment(db, part, subject)
                if result in stats:
                    stats[result] += 1
        db.commit()
        return stats
    finally:
        try:
            conn.logout()
        except Exception:
            pass
