"""Screening engine.

Principles:
1. Hard qualification checks (硬性资格核验) and composite scoring (综合评分) are separate.
2. Unknown information is never treated as failing a condition — it yields
   status "unknown" and forces the overall qualification to "needs_review".
3. Sensitive / legally constrained conditions (political status, age, hukou)
   are only applied when explicitly configured in the rule, and only as
   independent hard checks — never in the default composite score.
4. The engine produces advisory suggestions only; final decisions are human.
"""
from ..models import Resume, Rule

EDU_ORDER = {"大专": 1, "本科": 2, "硕士": 3, "博士": 4}


def _edu_rank(edu: str) -> int:
    return EDU_ORDER.get(edu, 0)


def _major_matches(resume_major: str, accepted: list[str]) -> bool | None:
    if not accepted:
        return True
    if not resume_major:
        return None  # unknown
    return any(a and (a in resume_major or resume_major in a) for a in accepted)


def run_screening(resume: Resume, rule: Rule) -> dict:
    cfg = rule.config or {}
    hard_checks: list[dict] = []
    unknown_count = 0
    fail_count = 0

    def add_check(item: str, requirement: str, status: str, evidence: str):
        nonlocal unknown_count, fail_count
        if status == "unknown":
            unknown_count += 1
        elif status == "fail":
            fail_count += 1
        hard_checks.append(
            {"item": item, "requirement": requirement, "status": status, "evidence": evidence}
        )

    # --- education (hard) ---
    min_edu = cfg.get("min_education")
    if min_edu:
        if not resume.education:
            add_check("学历要求", f"不低于{min_edu}", "unknown", "简历中未识别到学历信息")
        else:
            ok = _edu_rank(resume.education) >= _edu_rank(min_edu)
            add_check(
                "学历要求", f"不低于{min_edu}", "pass" if ok else "fail",
                f"识别学历：{resume.education}",
            )

    # --- major (hard only when explicitly required) ---
    accepted = cfg.get("accepted_majors") or []
    if accepted and cfg.get("major_match_required"):
        m = _major_matches(resume.major, accepted)
        if m is None:
            add_check("专业要求", "/".join(accepted), "unknown", "简历中未识别到专业信息")
        else:
            add_check(
                "专业要求", "/".join(accepted), "pass" if m else "fail",
                f"识别专业：{resume.major or '未知'}",
            )

    # --- age (sensitive; independent check, only when configured) ---
    max_age = cfg.get("max_age")
    if max_age:
        if resume.age is None:
            add_check("年龄条件", f"{max_age} 周岁以下", "unknown", "简历中未识别到出生日期/年龄")
        else:
            ok = resume.age < max_age
            add_check(
                "年龄条件", f"{max_age} 周岁以下", "pass" if ok else "fail",
                f"识别年龄：{resume.age} 岁（依据学校招聘政策独立核验）",
            )

    # --- party membership (辅导员岗位等; independent check, only when configured) ---
    if cfg.get("require_party_member"):
        ps = resume.political_status
        if not ps:
            add_check("政治面貌", "中共党员（含预备党员）", "unknown", "简历中未识别到政治面貌")
        else:
            ok = ps == "中共党员"
            add_check(
                "政治面貌", "中共党员（含预备党员）", "pass" if ok else "fail",
                f"识别政治面貌：{ps}",
            )

    # --- fresh-only ---
    if cfg.get("fresh_only"):
        if resume.is_fresh == "unknown":
            add_check("应届身份", "仅限应届毕业生", "unknown", "无法确认是否应届毕业生")
        else:
            ok = resume.is_fresh == "fresh"
            add_check(
                "应届身份", "仅限应届毕业生", "pass" if ok else "fail",
                "应届毕业生" if resume.is_fresh == "fresh" else "非应届毕业生",
            )

    # --- non-fresh: Shanghai hukou or valid residence permit ---
    if cfg.get("non_fresh_requires") == "shanghai_hukou_or_residence_permit" and resume.is_fresh == "not_fresh":
        hukou_sh = bool(resume.hukou and "上海" in resume.hukou)
        permit = resume.shanghai_residence_permit
        if hukou_sh:
            add_check("户籍/居住证", "上海户籍或有效上海居住证", "pass", f"户籍：{resume.hukou}")
        elif permit == "valid":
            add_check("户籍/居住证", "上海户籍或有效上海居住证", "pass", "持有有效上海居住证")
        elif permit == "unknown" or not resume.hukou:
            add_check(
                "户籍/居住证", "上海户籍或有效上海居住证", "unknown",
                "户籍或居住证信息不完整，需人工核验原件",
            )
        else:
            add_check(
                "户籍/居住证", "上海户籍或有效上海居住证", "fail",
                f"户籍：{resume.hukou or '外地'}，无有效上海居住证记录",
            )

    # --- min work years ---
    min_wy = cfg.get("min_work_years") or 0
    if min_wy:
        if resume.work_years is None:
            add_check("工作经验", f"至少 {min_wy} 年", "unknown", "未识别到工作年限")
        else:
            ok = resume.work_years >= min_wy
            add_check(
                "工作经验", f"至少 {min_wy} 年", "pass" if ok else "fail",
                f"识别工作经验：{resume.work_years} 年",
            )

    if fail_count:
        qualification = "unqualified"
    elif unknown_count:
        qualification = "needs_review"
    else:
        qualification = "qualified"

    # --- composite scoring (advisory) ---
    scoring = cfg.get("scoring") or {}
    breakdown: list[dict] = []
    total = 0.0

    def add_score(item: str, points: float, maxp: float, reason: str):
        nonlocal total
        total += points
        breakdown.append({"item": item, "points": round(points, 1), "max": maxp, "reason": reason})

    tier_map = scoring.get("school_tier") or {}
    if tier_map:
        tier = resume.school_tier or ""
        maxp = max(tier_map.values()) if tier_map else 0
        if tier and tier in tier_map:
            add_score("学校层次", float(tier_map[tier]), float(maxp), f"{resume.school}（{tier}）")
        else:
            add_score("学校层次", 0.0, float(maxp), "学校层次未知，不计分（不视为不符合）")

    edu_map = scoring.get("education") or {}
    if edu_map:
        maxp = max(edu_map.values()) if edu_map else 0
        if resume.education and resume.education in edu_map:
            add_score("学历层次", float(edu_map[resume.education]), float(maxp), resume.education)
        else:
            add_score("学历层次", 0.0, float(maxp), "学历未知，不计分")

    major_pts = float(scoring.get("major_match") or 0)
    if major_pts:
        m = _major_matches(resume.major, cfg.get("accepted_majors") or [])
        if m is True:
            add_score("专业匹配", major_pts, major_pts, f"专业 {resume.major} 匹配")
        elif m is None:
            add_score("专业匹配", 0.0, major_pts, "专业未知，不计分")
        else:
            add_score("专业匹配", 0.0, major_pts, f"专业 {resume.major} 不在要求范围内")

    if scoring.get("fresh_bonus") and resume.is_fresh == "fresh":
        b = float(scoring["fresh_bonus"])
        add_score("应届生优先", b, b, "应届毕业生（按规则加分）")

    wy_cfg = scoring.get("work_years") or {}
    if wy_cfg and resume.work_years is not None:
        per = float(wy_cfg.get("per_year", 0))
        cap = float(wy_cfg.get("max", 0))
        pts = min(resume.work_years * per, cap)
        add_score("工作经验", pts, cap, f"{resume.work_years} 年 × {per} 分/年")

    rel = float(scoring.get("related_experience_bonus") or 0)
    if rel and resume.raw_text and any(k in resume.raw_text for k in ("辅导员", "学生工作", "班主任", "思政")):
        add_score("相关经验优先", rel, rel, "简历包含辅导员/学生工作相关经历关键词")

    max_total = sum(b["max"] for b in breakdown) or 1
    score_pct = round(total / max_total * 100, 1)

    # --- advisory suggestion ---
    parts: list[str] = []
    if qualification == "unqualified":
        failed = [c["item"] for c in hard_checks if c["status"] == "fail"]
        parts.append(f"硬性条件未满足：{'、'.join(failed)}。建议人工复核证据后再做决定。")
    elif qualification == "needs_review":
        unk = [c["item"] for c in hard_checks if c["status"] == "unknown"]
        parts.append(f"以下信息缺失，需人工核实原件：{'、'.join(unk)}。系统不会将未知信息视为不符合。")
    else:
        parts.append("硬性资格核验全部通过。")
    parts.append(f"综合评分 {score_pct} 分（仅供参考，不构成录用或淘汰依据）。")
    parts.append("AI 仅提供辅助分析，最终决定须由人事工作人员作出。")

    return {
        "hard_checks": hard_checks,
        "qualification": qualification,
        "score": score_pct,
        "score_breakdown": breakdown,
        "suggestion": " ".join(parts),
    }
