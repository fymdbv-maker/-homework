from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.orm import Session

from ..database import get_db
from ..deps import audit, get_current_user, require_role
from ..models import Position, Rule, User
from ..schemas import PositionCreate, PositionOut, RuleOut, RuleUpsert

router = APIRouter(prefix="/api", tags=["positions-rules"])


@router.get("/positions", response_model=list[PositionOut])
def list_positions(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    return db.query(Position).order_by(Position.id).all()


@router.post("/positions", response_model=PositionOut)
def create_position(
    body: PositionCreate, request: Request,
    db: Session = Depends(get_db), user: User = Depends(require_role("admin", "hr")),
):
    if db.query(Position).filter(Position.code == body.code).first():
        raise HTTPException(400, "岗位编码已存在")
    p = Position(**body.model_dump())
    db.add(p)
    db.flush()
    audit(db, user, "create_position", "position", p.id, body.name, request)
    db.commit()
    db.refresh(p)
    return p


@router.put("/positions/{position_id}", response_model=PositionOut)
def update_position(
    position_id: int, body: PositionCreate, request: Request,
    db: Session = Depends(get_db), user: User = Depends(require_role("admin", "hr")),
):
    p = db.get(Position, position_id)
    if not p:
        raise HTTPException(404, "岗位不存在")
    for k, v in body.model_dump().items():
        setattr(p, k, v)
    audit(db, user, "update_position", "position", p.id, body.name, request)
    db.commit()
    db.refresh(p)
    return p


@router.put("/positions/{position_id}/toggle", response_model=PositionOut)
def toggle_position(
    position_id: int, request: Request,
    db: Session = Depends(get_db), user: User = Depends(require_role("admin", "hr")),
):
    p = db.get(Position, position_id)
    if not p:
        raise HTTPException(404, "岗位不存在")
    p.active = not p.active
    audit(db, user, "toggle_position", "position", p.id, f"active={p.active}", request)
    db.commit()
    db.refresh(p)
    return p


@router.get("/rules", response_model=list[RuleOut])
def list_rules(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    return db.query(Rule).order_by(Rule.updated_at.desc()).all()


@router.get("/rules/{rule_id}", response_model=RuleOut)
def get_rule(rule_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    rule = db.get(Rule, rule_id)
    if not rule:
        raise HTTPException(404, "规则不存在")
    return rule


@router.get("/rules/{rule_id}/history", response_model=list[RuleOut])
def rule_history(rule_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    rule = db.get(Rule, rule_id)
    if not rule:
        raise HTTPException(404, "规则不存在")
    return (
        db.query(Rule)
        .filter(Rule.position_id == rule.position_id, Rule.name == rule.name)
        .order_by(Rule.version.desc())
        .all()
    )


@router.post("/rules", response_model=RuleOut)
def create_rule(
    body: RuleUpsert, request: Request,
    db: Session = Depends(get_db), user: User = Depends(require_role("admin", "hr")),
):
    if not db.get(Position, body.position_id):
        raise HTTPException(404, "岗位不存在")
    rule = Rule(**body.model_dump(), version=1, created_by=user.username)
    db.add(rule)
    db.flush()
    audit(db, user, "create_rule", "rule", rule.id, f"{rule.name} v1", request)
    db.commit()
    db.refresh(rule)
    return rule


@router.put("/rules/{rule_id}", response_model=RuleOut)
def update_rule(
    rule_id: int, body: RuleUpsert, request: Request,
    db: Session = Depends(get_db), user: User = Depends(require_role("admin", "hr")),
):
    old = db.get(Rule, rule_id)
    if not old:
        raise HTTPException(404, "规则不存在")
    # create a new version row; keep history immutable
    new = Rule(
        position_id=body.position_id, name=body.name, config=body.config,
        enabled=body.enabled, version=old.version + 1, created_by=user.username,
        change_note=body.change_note,
    )
    old.enabled = False  # supersede old version
    db.add(new)
    db.flush()
    audit(db, user, "update_rule", "rule", new.id, f"{new.name} v{new.version}（基于 v{old.version}）", request)
    db.commit()
    db.refresh(new)
    return new


@router.put("/rules/{rule_id}/toggle", response_model=RuleOut)
def toggle_rule(
    rule_id: int, request: Request,
    db: Session = Depends(get_db), user: User = Depends(require_role("admin", "hr")),
):
    rule = db.get(Rule, rule_id)
    if not rule:
        raise HTTPException(404, "规则不存在")
    rule.enabled = not rule.enabled
    audit(db, user, "toggle_rule", "rule", rule.id, f"enabled={rule.enabled}", request)
    db.commit()
    db.refresh(rule)
    return rule


@router.delete("/rules/{rule_id}")
def delete_rule(
    rule_id: int, request: Request,
    db: Session = Depends(get_db), user: User = Depends(require_role("admin")),
):
    rule = db.get(Rule, rule_id)
    if not rule:
        raise HTTPException(404, "规则不存在")
    audit(db, user, "delete_rule", "rule", rule.id, rule.name, request)
    db.delete(rule)
    db.commit()
    return {"ok": True}
