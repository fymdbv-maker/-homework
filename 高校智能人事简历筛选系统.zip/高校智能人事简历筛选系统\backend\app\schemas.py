"""Pydantic schemas."""
from datetime import datetime
from typing import Any

from pydantic import BaseModel, ConfigDict


class LoginRequest(BaseModel):
    username: str
    password: str


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: "UserOut"


class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    username: str
    display_name: str
    role: str
    active: bool
    created_at: datetime


class UserCreate(BaseModel):
    username: str
    password: str
    display_name: str = ""
    role: str = "hr"


class UserUpdate(BaseModel):
    display_name: str | None = None
    role: str | None = None
    active: bool | None = None
    password: str | None = None


class PositionOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    name: str
    code: str
    department: str
    description: str
    active: bool


class PositionCreate(BaseModel):
    name: str
    code: str
    department: str = ""
    description: str = ""


class RuleOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    position_id: int
    name: str
    version: int
    config: dict[str, Any]
    enabled: bool
    created_by: str
    change_note: str
    created_at: datetime
    updated_at: datetime


class RuleUpsert(BaseModel):
    position_id: int
    name: str
    config: dict[str, Any] = {}
    enabled: bool = True
    change_note: str = ""


class ResumeOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    filename: str
    file_type: str
    file_size: int
    source: str
    name: str
    gender: str
    target_position: str
    education: str
    school: str
    school_tier: str
    major: str
    graduation_date: str
    work_years: float | None
    is_fresh: str
    birth_date: str
    age: int | None
    political_status: str
    hukou: str
    shanghai_residence_permit: str
    phone: str
    email: str
    parse_status: str
    parse_notes: str
    created_at: datetime


class ResumeDetail(ResumeOut):
    raw_text: str
    field_sources: dict[str, Any]
    results: list["ScreeningResultOut"] = []


class ResumeManualUpdate(BaseModel):
    """Human correction of parsed fields."""
    name: str | None = None
    gender: str | None = None
    target_position: str | None = None
    education: str | None = None
    school: str | None = None
    school_tier: str | None = None
    major: str | None = None
    graduation_date: str | None = None
    work_years: float | None = None
    is_fresh: str | None = None
    birth_date: str | None = None
    age: int | None = None
    political_status: str | None = None
    hukou: str | None = None
    shanghai_residence_permit: str | None = None
    phone: str | None = None
    email: str | None = None


class ScreeningResultOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    resume_id: int
    rule_id: int
    rule_version: int
    position_name: str
    hard_checks: list[dict[str, Any]]
    qualification: str
    score: float
    score_breakdown: list[dict[str, Any]]
    suggestion: str
    status: str
    reviewer: str
    review_note: str
    reviewed_at: datetime | None
    created_at: datetime


class RunScreeningRequest(BaseModel):
    rule_id: int
    resume_ids: list[int] | None = None  # None = all resumes without a result for this rule
    rerun: bool = False                  # True = re-screen even if a result exists


class ReviewRequest(BaseModel):
    status: str  # approved / rejected / pending
    review_note: str = ""


class EmailConfigIn(BaseModel):
    host: str
    port: int = 993
    username: str
    password: str = ""   # empty = keep existing
    use_ssl: bool = True
    enabled: bool = True


class EmailConfigOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int | None = None
    host: str = ""
    port: int = 993
    username: str = ""
    has_password: bool = False
    use_ssl: bool = True
    enabled: bool = False
    configured: bool = False
    demo_mode: bool = True
    last_sync_at: datetime | None = None
    last_sync_status: str = ""
    last_sync_message: str = ""


class ImportLogOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    source: str
    reference: str
    attachment_name: str
    status: str
    detail: str
    created_at: datetime


class AuditLogOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    username: str
    action: str
    target_type: str
    target_id: str
    detail: str
    ip: str
    created_at: datetime


class SettingIn(BaseModel):
    key: str
    value: str
    description: str = ""


class SettingOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    key: str
    value: str
    description: str


class ChangePasswordIn(BaseModel):
    old_password: str
    new_password: str


TokenResponse.model_rebuild()
ResumeDetail.model_rebuild()
