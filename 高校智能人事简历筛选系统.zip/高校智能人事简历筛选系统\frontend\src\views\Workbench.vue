<template>
  <div>
    <el-card shadow="never">
      <div class="toolbar">
        <el-input v-model="query.keyword" placeholder="搜索姓名 / 学校 / 专业" clearable style="width: 200px" @change="load(1)" />
        <el-select v-model="query.position" placeholder="岗位" clearable style="width: 130px" @change="load(1)">
          <el-option v-for="p in positions" :key="p.id" :label="p.name" :value="p.name" />
        </el-select>
        <el-select v-model="query.qualification" placeholder="硬性核验" clearable style="width: 130px" @change="load(1)">
          <el-option v-for="(v, k) in qualMap" :key="k" :label="v.label" :value="k" />
        </el-select>
        <el-select v-model="query.status" placeholder="审核状态" clearable style="width: 120px" @change="load(1)">
          <el-option v-for="(v, k) in reviewStatusMap" :key="k" :label="v.label" :value="k" />
        </el-select>
        <el-select v-model="query.education" placeholder="学历" clearable style="width: 100px" @change="load(1)">
          <el-option v-for="e in educationOptions" :key="e" :label="e" :value="e" />
        </el-select>
        <el-select v-model="query.school_tier" placeholder="学校层次" clearable style="width: 110px" @change="load(1)">
          <el-option v-for="t in schoolTierOptions" :key="t" :label="t" :value="t" />
        </el-select>
        <el-select v-model="query.is_fresh" placeholder="应届" clearable style="width: 110px" @change="load(1)">
          <el-option label="应届毕业生" value="fresh" /><el-option label="非应届" value="not_fresh" /><el-option label="待核实" value="unknown" />
        </el-select>
        <el-select v-model="query.major_match" placeholder="专业匹配" clearable style="width: 110px" @change="load(1)">
          <el-option label="匹配" value="yes" /><el-option label="不匹配" value="no" />
        </el-select>
        <el-button type="primary" @click="load(1)">查询</el-button>
      </div>

      <div class="quick-filters">
        <span class="qf-label">快速筛选：</span>
        <el-button size="small" @click="quick('qualification', 'qualified')">符合条件</el-button>
        <el-button size="small" @click="quick('qualification', 'needs_review')">待人工核实</el-button>
        <el-button size="small" @click="quick('status', 'pending')">待审核</el-button>
        <el-button size="small" @click="quick('is_fresh', 'fresh')">应届优先</el-button>
        <el-button size="small" @click="quick('school_tier', '985')">985 院校</el-button>
        <el-button size="small" text type="danger" @click="resetFilters">清除全部筛选</el-button>
        <div style="flex: 1" />
        <el-button size="small" type="success" :disabled="!selected.length" @click="batchReview('approved')">批量通过（{{ selected.length }}）</el-button>
        <el-button size="small" type="danger" :disabled="!selected.length" @click="batchReview('rejected')">批量不通过</el-button>
        <el-button size="small" @click="exportCsv">导出 CSV</el-button>
      </div>

      <el-table :data="rows" v-loading="loading" @selection-change="selected = $event">
        <el-table-column type="selection" width="45" />
        <el-table-column label="姓名" width="100">
          <template #default="{ row }">
            <el-link type="primary" @click="openDetail(row)">{{ show(row.resume?.name) }}</el-link>
          </template>
        </el-table-column>
        <el-table-column prop="position_name" label="岗位" width="110" />
        <el-table-column label="学历" width="70"><template #default="{ row }">{{ show(row.resume?.education) }}</template></el-table-column>
        <el-table-column label="院校" min-width="120" show-overflow-tooltip>
          <template #default="{ row }">
            {{ show(row.resume?.school) }}
            <el-tag v-if="row.resume?.school_tier" size="small">{{ row.resume.school_tier }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="专业" min-width="100" show-overflow-tooltip><template #default="{ row }">{{ show(row.resume?.major) }}</template></el-table-column>
        <el-table-column label="应届" width="80">
          <template #default="{ row }"><el-tag size="small" :type="freshMap[row.resume?.is_fresh]?.type">{{ freshMap[row.resume?.is_fresh]?.label }}</el-tag></template>
        </el-table-column>
        <el-table-column label="硬性核验" width="100">
          <template #default="{ row }"><el-tag size="small" :type="qualMap[row.qualification]?.type">{{ qualMap[row.qualification]?.label }}</el-tag></template>
        </el-table-column>
        <el-table-column prop="score" label="评分" width="80" sortable />
        <el-table-column label="审核状态" width="90">
          <template #default="{ row }"><el-tag size="small" :type="reviewStatusMap[row.status]?.type">{{ reviewStatusMap[row.status]?.label }}</el-tag></template>
        </el-table-column>
        <el-table-column label="操作" width="140" fixed="right">
          <template #default="{ row }">
            <el-button text type="primary" size="small" @click="openReview(row)">审核</el-button>
            <el-button text size="small" @click="openDetail(row)">明细</el-button>
          </template>
        </el-table-column>
      </el-table>

      <el-pagination
        style="margin-top: 12px; justify-content: flex-end"
        background layout="total, sizes, prev, pager, next" :total="total"
        v-model:current-page="query.page" v-model:page-size="query.page_size"
        :page-sizes="[10, 20, 50]" @current-change="load()" @size-change="load(1)"
      />
    </el-card>

    <el-dialog v-model="reviewDialog" title="人工审核" width="480px">
      <template v-if="activeRow">
        <p><b>{{ show(activeRow.resume?.name) }}</b> — {{ activeRow.position_name }}，硬性核验：
          <el-tag size="small" :type="qualMap[activeRow.qualification]?.type">{{ qualMap[activeRow.qualification]?.label }}</el-tag>
          ，评分 {{ activeRow.score }}
        </p>
        <el-radio-group v-model="reviewForm.status">
          <el-radio value="approved">通过</el-radio>
          <el-radio value="rejected">不通过</el-radio>
          <el-radio value="pending">暂缓（待审核）</el-radio>
        </el-radio-group>
        <el-input v-model="reviewForm.review_note" type="textarea" :rows="3" placeholder="审核备注（可选）" style="margin-top: 12px" />
      </template>
      <template #footer>
        <el-button @click="reviewDialog = false">取消</el-button>
        <el-button type="primary" :loading="reviewing" @click="submitReview">提交审核</el-button>
      </template>
    </el-dialog>

    <el-drawer v-model="detailDrawer" title="候选人评分明细" size="560px">
      <template v-if="activeRow">
        <el-descriptions :column="2" border size="small">
          <el-descriptions-item label="姓名">{{ show(activeRow.resume?.name) }}</el-descriptions-item>
          <el-descriptions-item label="岗位">{{ activeRow.position_name }}</el-descriptions-item>
          <el-descriptions-item label="学历">{{ show(activeRow.resume?.education) }}</el-descriptions-item>
          <el-descriptions-item label="政治面貌">{{ show(activeRow.resume?.political_status) }}</el-descriptions-item>
          <el-descriptions-item label="年龄">{{ activeRow.resume?.age ?? UNKNOWN }}</el-descriptions-item>
          <el-descriptions-item label="工作经验">{{ activeRow.resume?.work_years === null ? UNKNOWN : activeRow.resume?.work_years + ' 年' }}</el-descriptions-item>
          <el-descriptions-item label="审核人">{{ activeRow.reviewer || '—' }}</el-descriptions-item>
          <el-descriptions-item label="审核备注">{{ activeRow.review_note || '—' }}</el-descriptions-item>
        </el-descriptions>
        <h4>硬性资格核验</h4>
        <el-table :data="activeRow.hard_checks" size="small">
          <el-table-column prop="item" label="核验项" width="100" />
          <el-table-column prop="requirement" label="要求" width="140" show-overflow-tooltip />
          <el-table-column label="结果" width="80">
            <template #default="{ row }"><el-tag size="small" :type="checkStatusMap[row.status]?.type">{{ checkStatusMap[row.status]?.label }}</el-tag></template>
          </el-table-column>
          <el-table-column prop="evidence" label="依据" show-overflow-tooltip />
        </el-table>
        <h4 style="margin-top: 16px">综合评分明细</h4>
        <el-table :data="activeRow.score_breakdown" size="small">
          <el-table-column prop="item" label="评分项" width="120" />
          <el-table-column prop="points" label="得分" width="70" />
          <el-table-column prop="max" label="满分" width="70" />
          <el-table-column prop="reason" label="说明" show-overflow-tooltip />
        </el-table>
        <el-alert style="margin-top: 12px" type="info" :closable="false" :title="'AI 辅助建议（仅供参考）：' + (activeRow.suggestion || '无')" />
        <el-button style="margin-top: 12px" size="small" @click="$router.push(`/resumes/${activeRow.resume_id}`)">查看完整简历</el-button>
      </template>
    </el-drawer>
  </div>
</template>

<script setup lang="ts">
import { onMounted, reactive, ref } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import api from '../api'
import { show, UNKNOWN, educationOptions, schoolTierOptions, freshMap, qualMap, reviewStatusMap, checkStatusMap } from '../display'

const loading = ref(false)
const rows = ref<any[]>([])
const total = ref(0)
const positions = ref<any[]>([])
const selected = ref<any[]>([])
const query = reactive<any>({ page: 1, page_size: 10, keyword: '', position: '', qualification: '', status: '', education: '', school_tier: '', is_fresh: '', major_match: '' })

const reviewDialog = ref(false)
const detailDrawer = ref(false)
const activeRow = ref<any>(null)
const reviewing = ref(false)
const reviewForm = reactive({ status: 'approved', review_note: '' })

async function load(page?: number) {
  if (page) query.page = page
  loading.value = true
  try {
    const { data } = await api.get('/screening/results', { params: query })
    rows.value = data.items
    total.value = data.total
  } finally {
    loading.value = false
  }
}

function quick(key: string, value: string) {
  resetFilters()
  query[key] = value
  load(1)
}

function resetFilters() {
  Object.assign(query, { keyword: '', position: '', qualification: '', status: '', education: '', school_tier: '', is_fresh: '', major_match: '' })
  load(1)
}

function openReview(row: any) {
  activeRow.value = row
  reviewForm.status = row.status === 'pending' ? 'approved' : row.status
  reviewForm.review_note = row.review_note
  reviewDialog.value = true
}

async function submitReview() {
  reviewing.value = true
  try {
    await api.post(`/screening/results/${activeRow.value.id}/review`, reviewForm)
    ElMessage.success('审核已提交')
    reviewDialog.value = false
    load()
  } finally {
    reviewing.value = false
  }
}

async function batchReview(status: string) {
  const { value } = await ElMessageBox.prompt('批量审核备注（可留空）', '批量审核', { confirmButtonText: '确定', cancelButtonText: '取消', inputValue: '' })
  await api.post('/screening/results/batch-review', selected.value.map((r) => r.id), { params: { status, note: value || '' } })
  ElMessage.success(`已批量处理 ${selected.value.length} 条`)
  load()
}

async function exportCsv() {
  const { data } = await api.get('/screening/export', { params: { position: query.position, qualification: query.qualification, status: query.status }, responseType: 'blob' })
  const url = URL.createObjectURL(new Blob([data], { type: 'text/csv;charset=utf-8' }))
  const a = document.createElement('a')
  a.href = url
  a.download = '筛选结果导出.csv'
  a.click()
  URL.revokeObjectURL(url)
}

function openDetail(row: any) {
  activeRow.value = row
  detailDrawer.value = true
}

onMounted(async () => {
  const { data } = await api.get('/positions')
  positions.value = data
  load()
})
</script>

<style scoped>
.toolbar { display: flex; gap: 10px; flex-wrap: wrap; }
.quick-filters { display: flex; gap: 8px; align-items: center; margin-top: 10px; flex-wrap: wrap; }
.qf-label { color: #909399; font-size: 13px; }
</style>
