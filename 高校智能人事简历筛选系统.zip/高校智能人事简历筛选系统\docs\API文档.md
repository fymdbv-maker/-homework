# API 文档

Base URL：`http://localhost:8000/api`；除登录外所有接口需请求头 `Authorization: Bearer <token>`。
交互式文档：http://localhost:8000/docs（Swagger UI）。

## 认证

| 方法 | 路径 | 说明 |
| --- | --- | --- |
| POST | /auth/login | 登录。入参 `{username, password}`；返回 `{access_token, token_type, user}` |
| GET | /auth/me | 当前用户信息 |
| POST | /auth/change-password | 修改本人密码 `{old_password, new_password}` |

## 仪表盘

| 方法 | 路径 | 说明 |
| --- | --- | --- |
| GET | /dashboard/stats | 统计卡片 + 最近简历 + 最近筛选结果 |

## 简历

| 方法 | 路径 | 说明 |
| --- | --- | --- |
| GET | /resumes | 列表。参数：`page, page_size, keyword, education, is_fresh, parse_status, school_tier, source` |
| POST | /resumes/upload | 上传（multipart，字段名 `files`，可多文件）。支持 pdf/docx/doc/txt/jpg/jpeg/png/bmp/webp；重复文件跳过并记录 |
| GET | /resumes/{id} | 详情（含 raw_text、field_sources、results） |
| PUT | /resumes/{id} | 人工修正字段（仅需传修改字段） |
| POST | /resumes/{id}/reparse | 重新解析 |
| DELETE | /resumes/{id} | 删除（含文件与筛选结果） |
| GET | /resumes/{id}/file | 下载原始文件（需登录） |

## 筛选

| 方法 | 路径 | 说明 |
| --- | --- | --- |
| POST | /screening/run | 运行筛选 `{rule_id, resume_ids?: number[]\|null, rerun?: bool}` |
| GET | /screening/results | 结果列表。参数：`page, page_size, position, qualification, status, education, school_tier, is_fresh, major_match(yes/no), keyword` |
| POST | /screening/results/{id}/review | 单人审核 `{status: approved/rejected/pending, review_note}`（admin/hr） |
| POST | /screening/results/batch-review | 批量审核。body 为 id 数组，query：`status, note`（admin/hr） |
| GET | /screening/export | 导出 CSV。参数：`position, qualification, status` |

`qualification`：qualified 符合 / unqualified 不符合 / needs_review 待人工核实。
`hard_checks[].status`：pass / fail / unknown（未知不作 fail）。

## 岗位与规则

| 方法 | 路径 | 说明 |
| --- | --- | --- |
| GET | /positions | 岗位列表 |
| POST | /positions | 新增岗位（admin/hr）`{name, code, department, description}` |
| PUT | /positions/{id} | 编辑岗位 |
| PUT | /positions/{id}/toggle | 启用/停用 |
| GET | /rules | 规则列表（含历史版本） |
| GET | /rules/{id} | 规则详情 |
| GET | /rules/{id}/history | 版本历史 |
| POST | /rules | 新增规则 `{position_id, name, config, enabled, change_note}` |
| PUT | /rules/{id} | 修改规则（生成新版本，旧版本自动停用） |
| PUT | /rules/{id}/toggle | 启用/停用 |
| DELETE | /rules/{id} | 删除（仅 admin） |

## 邮箱导入

| 方法 | 路径 | 说明 |
| --- | --- | --- |
| GET | /email/config | 当前配置（`demo_mode` 标识是否演示模式，密码不返回） |
| PUT | /email/config | 保存配置（admin）；`password` 留空表示不修改 |
| POST | /email/sync?limit=50 | 手动同步（admin/hr）；未配置返回 `{ok:false, demo_mode:true}` |
| GET | /email/logs | 导入日志分页 |

## 系统

| 方法 | 路径 | 说明 |
| --- | --- | --- |
| GET | /users | 用户列表（admin） |
| POST | /users | 新增用户 `{username, password, display_name, role}` |
| PUT | /users/{id} | 更新用户（可重置密码、启停） |
| GET | /audit-logs | 审计日志分页，参数 `page, page_size, action` |
| GET | /settings | 系统参数（敏感键值脱敏为 ******） |
| PUT | /settings | 写参数 `{key, value, description}`；值为 ****** 时不覆盖 |
| GET | /model-config | LLM 配置状态（不暴露密钥） |

## 错误格式

```json
{"detail": "错误描述"}
```

401 未登录/过期；403 角色不足；404 资源不存在；400 参数或业务错误。
