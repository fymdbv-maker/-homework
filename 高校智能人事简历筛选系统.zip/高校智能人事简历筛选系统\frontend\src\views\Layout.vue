<template>
  <el-container class="layout">
    <el-aside :width="collapsed ? '64px' : '220px'" class="sidebar">
      <div class="logo" @click="$router.push('/dashboard')">
        <span v-if="!collapsed">高校人事筛选系统</span>
        <span v-else>HR</span>
      </div>
      <el-menu
        :default-active="$route.path"
        :collapse="collapsed"
        router
        background-color="#001529"
        text-color="#a6adb4"
        active-text-color="#ffffff"
        class="side-menu"
      >
        <el-menu-item index="/dashboard"><el-icon><DataAnalysis /></el-icon><template #title>首页仪表盘</template></el-menu-item>
        <el-menu-item index="/resumes"><el-icon><Document /></el-icon><template #title>简历管理</template></el-menu-item>
        <el-menu-item index="/screening"><el-icon><Filter /></el-icon><template #title>智能筛选</template></el-menu-item>
        <el-menu-item index="/workbench"><el-icon><Monitor /></el-icon><template #title>筛选工作台</template></el-menu-item>
        <el-menu-item index="/email"><el-icon><Message /></el-icon><template #title>邮箱简历导入</template></el-menu-item>
        <el-menu-item index="/rules"><el-icon><SetUp /></el-icon><template #title>岗位规则管理</template></el-menu-item>
        <el-menu-item index="/settings"><el-icon><Setting /></el-icon><template #title>系统设置与审计</template></el-menu-item>
      </el-menu>
    </el-aside>

    <el-container>
      <el-header class="header">
        <div class="header-left">
          <el-icon class="collapse-btn" @click="collapsed = !collapsed">
            <Expand v-if="collapsed" /><Fold v-else />
          </el-icon>
          <span class="page-title">{{ $route.meta.title || '' }}</span>
        </div>
        <div class="header-right">
          <el-tag type="success" size="small" effect="plain">系统运行中</el-tag>
          <el-dropdown @command="onCommand">
            <span class="user-info">
              <el-icon><Avatar /></el-icon>
              {{ user?.display_name || user?.username }}
              <el-tag size="small" style="margin-left:4px">{{ roleLabel }}</el-tag>
            </span>
            <template #dropdown>
              <el-dropdown-menu>
                <el-dropdown-item command="password">修改密码</el-dropdown-item>
                <el-dropdown-item command="logout" divided>退出登录</el-dropdown-item>
              </el-dropdown-menu>
            </template>
          </el-dropdown>
        </div>
      </el-header>
      <el-main class="main">
        <router-view />
      </el-main>
    </el-container>

    <el-dialog v-model="pwdDialog" title="修改密码" width="420px">
      <el-form :model="pwdForm" label-width="80px">
        <el-form-item label="原密码"><el-input v-model="pwdForm.old_password" type="password" show-password /></el-form-item>
        <el-form-item label="新密码"><el-input v-model="pwdForm.new_password" type="password" show-password /></el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="pwdDialog = false">取消</el-button>
        <el-button type="primary" :loading="pwdLoading" @click="changePassword">确定</el-button>
      </template>
    </el-dialog>
  </el-container>
</template>

<script setup lang="ts">
import { computed, reactive, ref } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import {
  DataAnalysis, Document, Filter, Monitor, Message, SetUp, Setting,
  Expand, Fold, Avatar,
} from '@element-plus/icons-vue'
import api from '../api'

const router = useRouter()
const collapsed = ref(false)
const user = computed(() => {
  try { return JSON.parse(localStorage.getItem('user') || 'null') } catch { return null }
})
const roleLabel = computed(() => ({ admin: '管理员', hr: '人事专员', viewer: '只读' }[user.value?.role] || user.value?.role || ''))

const pwdDialog = ref(false)
const pwdLoading = ref(false)
const pwdForm = reactive({ old_password: '', new_password: '' })

function onCommand(cmd: string) {
  if (cmd === 'logout') {
    ElMessageBox.confirm('确定退出登录吗？', '提示', { type: 'warning' }).then(() => {
      localStorage.removeItem('token')
      localStorage.removeItem('user')
      router.push('/login')
    }).catch(() => {})
  } else if (cmd === 'password') {
    pwdForm.old_password = ''
    pwdForm.new_password = ''
    pwdDialog.value = true
  }
}

async function changePassword() {
  if (!pwdForm.old_password || !pwdForm.new_password) {
    ElMessage.warning('请填写原密码和新密码')
    return
  }
  pwdLoading.value = true
  try {
    await api.post('/auth/change-password', pwdForm)
    ElMessage.success('密码修改成功')
    pwdDialog.value = false
  } catch { /* 拦截器已提示 */ } finally {
    pwdLoading.value = false
  }
}
</script>

<style scoped>
.layout { height: 100vh; }
.sidebar { background: #001529; transition: width 0.2s; overflow: hidden; }
.logo {
  height: 60px; display: flex; align-items: center; justify-content: center;
  color: #fff; font-weight: 600; font-size: 15px; cursor: pointer;
  border-bottom: 1px solid rgba(255, 255, 255, 0.08); white-space: nowrap;
}
.side-menu { border-right: none; }
.header {
  background: #fff; display: flex; align-items: center; justify-content: space-between;
  border-bottom: 1px solid #e4e7ed; padding: 0 20px;
}
.header-left { display: flex; align-items: center; gap: 12px; }
.collapse-btn { cursor: pointer; font-size: 18px; color: #606266; }
.page-title { font-size: 16px; font-weight: 600; color: #303133; }
.header-right { display: flex; align-items: center; gap: 16px; }
.user-info { display: flex; align-items: center; gap: 6px; cursor: pointer; color: #303133; }
.main { background: #f0f2f5; padding: 16px; overflow-y: auto; }
</style>
