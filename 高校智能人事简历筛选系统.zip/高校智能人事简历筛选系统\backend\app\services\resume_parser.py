"""Resume text extraction + field parsing.

Honesty rules:
- Fields that cannot be recognized stay empty and are shown as "待核实" in the UI.
- Image files require an OCR engine (Tesseract). If unavailable we mark the resume
  as partial and keep fields unknown instead of fabricating content.
"""
import re
import shutil
import subprocess
from pathlib import Path

EDUCATION_LEVELS = ["博士", "硕士", "本科", "大专"]

# Small built-in tier list (extendable via system settings page later)
SCHOOL_985 = {
    "清华大学", "北京大学", "复旦大学", "上海交通大学", "浙江大学", "南京大学",
    "中国科学技术大学", "华中科技大学", "武汉大学", "西安交通大学", "中山大学",
    "四川大学", "哈尔滨工业大学", "同济大学", "北京师范大学", "东南大学",
    "北京航空航天大学", "北京理工大学", "中国人民大学", "南开大学", "天津大学",
    "山东大学", "厦门大学", "吉林大学", "中南大学", "大连理工大学", "电子科技大学",
    "湖南大学", "重庆大学", "西北工业大学", "兰州大学", "东北大学", "中国海洋大学",
    "华东师范大学", "华南理工大学", "中国农业大学", "中央民族大学", "国防科技大学",
}
SCHOOL_211_EXTRA = {
    "上海大学", "华东理工大学", "东华大学", "上海财经大学", "上海外国语大学",
    "北京邮电大学", "北京交通大学", "北京科技大学", "南京理工大学", "苏州大学",
    "武汉理工大学", "西南交通大学", "暨南大学", "郑州大学", "云南大学", "安徽大学",
}

POLITICAL_KEYWORDS = ["中共党员", "中共预备党员", "预备党员", "共青团员", "群众", "民主党派"]


def extract_text(path: Path, file_type: str) -> tuple[str, str]:
    """Return (text, note). note is empty on success."""
    ft = file_type.lower()
    try:
        if ft == ".pdf":
            return _extract_pdf(path)
        if ft == ".docx":
            return _extract_docx(path)
        if ft == ".doc":
            return _extract_doc(path)
        if ft == ".txt":
            return path.read_text(encoding="utf-8", errors="ignore"), ""
        if ft in {".jpg", ".jpeg", ".png", ".bmp", ".webp", ".gif"}:
            return _extract_image(path)
        return "", f"不支持的文件类型 {ft}"
    except Exception as exc:  # noqa: BLE001
        return "", f"文件解析失败: {exc}"


def _extract_pdf(path: Path) -> tuple[str, str]:
    import pdfplumber

    parts: list[str] = []
    with pdfplumber.open(str(path)) as pdf:
        for page in pdf.pages:
            parts.append(page.extract_text() or "")
    text = "\n".join(parts).strip()
    if not text:
        return "", "PDF 中未提取到文本（可能为扫描件，需 OCR）"
    return text, ""


def _extract_docx(path: Path) -> tuple[str, str]:
    import docx

    doc = docx.Document(str(path))
    parts = [p.text for p in doc.paragraphs if p.text.strip()]
    for table in doc.tables:
        for row in table.rows:
            parts.append(" ".join(cell.text for cell in row.cells))
    text = "\n".join(parts).strip()
    return (text, "") if text else ("", "DOCX 中未提取到文本")


def _extract_doc(path: Path) -> tuple[str, str]:
    # Legacy .doc: crude printable-string extraction; better than nothing, flagged partial.
    data = path.read_bytes()
    text = re.sub(rb"[^\x09\x0a\x0d\x20-\x7e\x80-\xff]+", b" ", data).decode("gb18030", errors="ignore")
    text = re.sub(r"\s{2,}", " ", text).strip()
    if len(text) < 30:
        return "", "旧版 .doc 解析受限，请另存为 .docx 或 PDF 后重新上传"
    return text, "旧版 .doc 文件，解析结果可能不完整"


def _extract_image(path: Path) -> tuple[str, str]:
    tesseract = shutil.which("tesseract")
    if not tesseract:
        return "", "未检测到 Tesseract OCR，图片简历字段标记为待核实"
    try:
        out = subprocess.run(
            [tesseract, str(path), "stdout", "-l", "chi_sim+eng"],
            capture_output=True, text=True, timeout=120,
        )
        text = (out.stdout or "").strip()
        return (text, "") if text else ("", "OCR 未识别到文本")
    except Exception as exc:  # noqa: BLE001
        return "", f"OCR 失败: {exc}"


def parse_fields(text: str) -> tuple[dict, dict, list[str]]:
    """Extract structured fields. Returns (fields, sources, notes)."""
    fields: dict = {}
    sources: dict = {}
    notes: list[str] = []
    if not text:
        return fields, sources, ["无可用文本"]

    def evidence(pattern: str, flags: int = 0) -> str:
        m = re.search(pattern, text, flags)
        return m.group(0).strip()[:120] if m else ""

    # phone / email
    m = re.search(r"1[3-9]\d{9}", text)
    if m:
        fields["phone"] = m.group(0)
        sources["phone"] = m.group(0)
    m = re.search(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}", text)
    if m:
        fields["email"] = m.group(0)
        sources["email"] = m.group(0)

    # name — heuristic: line containing 姓名, else first 2-4 CJK chars of first line
    m = re.search(r"姓\s*名[:：\s]+([一-龥·]{2,4})", text)
    if m:
        fields["name"] = m.group(1)
        sources["name"] = m.group(0)
    else:
        first_line = (text.splitlines() or [""])[0].strip()
        m2 = re.match(r"^([一-龥·]{2,4})(?:\s|$|[，,|])", first_line)
        if m2 and m2.group(1) not in {"个人简历", "求职简历", "简历"}:
            fields["name"] = m2.group(1)
            sources["name"] = first_line[:60]

    # gender
    m = re.search(r"性\s*别[:：\s]+(男|女)", text)
    if m:
        fields["gender"] = m.group(1)
        sources["gender"] = m.group(0)

    # education — take the highest mentioned
    for level in EDUCATION_LEVELS:
        if level in text:
            fields["education"] = level
            sources["education"] = evidence(r".{0,10}" + level + r".{0,15}")
            break

    # school
    m = re.search(r"([一-龥]{2,12}(?:大学|学院|职业技术学院))", text)
    if m:
        fields["school"] = m.group(1)
        sources["school"] = m.group(0)
        school = m.group(1)
        if any(s in school for s in SCHOOL_985):
            fields["school_tier"] = "985"
        elif any(s in school for s in SCHOOL_211_EXTRA):
            fields["school_tier"] = "211"
        else:
            fields["school_tier"] = "普通本科"
        sources["school_tier"] = school

    # major — text immediately before "专业" (contiguous CJK run), or after "专业:"
    m = re.search(r"专\s*业[:：]\s*([一-龥（）()]{2,20})", text)
    if not m:
        m2 = re.search(r"([一-龥]{2,15})专业", text)
        if m2:
            candidate = m2.group(1)
            for junk in ("学历", "学位", "硕士研究生", "博士研究生", "研究生", "本科", "硕士", "博士", "大专"):
                candidate = candidate.replace(junk, "")
            if fields.get("school"):
                candidate = candidate.replace(fields["school"], "")
            candidate = candidate[-12:].strip()
            if len(candidate) >= 2:
                fields["major"] = candidate
                sources["major"] = m2.group(0)
    if m:
        fields["major"] = m.group(1).strip()
        sources["major"] = m.group(0)

    # graduation date
    m = re.search(r"(20\d{2})\s*[年./-]\s*(\d{1,2})\s*月?\s*(?:毕业|预计毕业)", text)
    if not m:
        m = re.search(r"毕业\s*时\s*间[:：\s]+(20\d{2})\s*[年./-]\s*(\d{1,2})", text)
    if m:
        fields["graduation_date"] = f"{m.group(1)}-{int(m.group(2)):02d}"
        sources["graduation_date"] = m.group(0)

    # birth date & age
    m = re.search(r"(?:出生\s*(?:日期|年月)?[:：\s]*)((?:19|20)\d{2})\s*[年./-]\s*(\d{1,2})", text)
    if m:
        fields["birth_date"] = f"{m.group(1)}-{int(m.group(2)):02d}"
        from datetime import date
        today = date.today()
        age = today.year - int(m.group(1)) - ((today.month, today.day) < (int(m.group(2)), 1))
        fields["age"] = age
        sources["birth_date"] = m.group(0)
        sources["age"] = m.group(0)
    else:
        m2 = re.search(r"年\s*龄[:：\s]+(\d{2})\s*岁?", text)
        if m2:
            fields["age"] = int(m2.group(1))
            sources["age"] = m2.group(0)

    # political status
    for kw in POLITICAL_KEYWORDS:
        if kw in text:
            fields["political_status"] = "中共党员" if kw in {"中共党员", "中共预备党员", "预备党员"} else kw
            sources["political_status"] = evidence(r".{0,8}" + kw + r".{0,8}")
            break

    # hukou
    m = re.search(r"户\s*(?:籍|口)[:：\s]+([一-龥]{2,10})", text)
    if m:
        fields["hukou"] = m.group(1)
        sources["hukou"] = m.group(0)
    elif "上海户籍" in text or "上海户口" in text:
        fields["hukou"] = "上海"
        sources["hukou"] = evidence(r".{0,8}上海户[籍口].{0,8}")

    # Shanghai residence permit
    if re.search(r"上海.{0,6}居住证", text):
        if re.search(r"居住证.{0,10}(有效|在有效期)", text) or re.search(r"(有效|持有).{0,6}居住证", text):
            fields["shanghai_residence_permit"] = "valid"
        else:
            fields["shanghai_residence_permit"] = "unknown"
        sources["shanghai_residence_permit"] = evidence(r".{0,10}居住证.{0,10}")

    # work years
    m = re.search(r"(\d{1,2})\s*年.{0,6}(?:工作|相关)?经验", text)
    if m:
        fields["work_years"] = float(m.group(1))
        sources["work_years"] = m.group(0)

    # fresh status
    if re.search(r"应届(毕业生|生)", text):
        fields["is_fresh"] = "fresh"
        sources["is_fresh"] = evidence(r".{0,10}应届.{0,10}")
    elif fields.get("work_years"):
        fields["is_fresh"] = "not_fresh"
        sources["is_fresh"] = f"{fields['work_years']} 年工作经验"
    elif fields.get("graduation_date"):
        from datetime import date
        grad_year = int(fields["graduation_date"][:4])
        fields["is_fresh"] = "fresh" if grad_year >= date.today().year else "not_fresh"
        sources["is_fresh"] = f"毕业时间 {fields['graduation_date']}"

    # target position
    m = re.search(r"(?:应聘|求职)\s*(?:岗位|职位|意向)?[:：\s]+([一-龥A-Za-z/]{2,20})", text)
    if m:
        fields["target_position"] = m.group(1).strip()
        sources["target_position"] = m.group(0)

    core_missing = [k for k in ("name", "education", "school") if k not in fields]
    if core_missing:
        notes.append("部分字段无法识别，已标记为待核实: " + ", ".join(core_missing))
    return fields, sources, notes
