"""Application configuration. Secrets come from environment variables / .env file."""
import os
from pathlib import Path

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent.parent
load_dotenv(BASE_DIR / ".env")


def _bool(v: str | None, default: bool = False) -> bool:
    if v is None:
        return default
    return v.strip().lower() in {"1", "true", "yes", "on"}


class Settings:
    # --- database ---
    # SQLite by default; set DATABASE_URL=postgresql+psycopg2://user:pass@host/db for PostgreSQL
    DATABASE_URL: str = os.getenv("DATABASE_URL", f"sqlite:///{(BASE_DIR / 'hr_screening.db').as_posix()}")

    # --- auth ---
    SECRET_KEY: str = os.getenv("SECRET_KEY", "dev-only-insecure-secret-change-me")
    ACCESS_TOKEN_EXPIRE_MINUTES: int = int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", "720"))

    # --- storage ---
    UPLOAD_DIR: Path = Path(os.getenv("UPLOAD_DIR", str(BASE_DIR / "uploads")))

    # --- encryption for stored credentials (email password etc.) ---
    CREDENTIAL_KEY: str = os.getenv("CREDENTIAL_KEY", "")  # Fernet key; generated on first run if empty

    # --- IMAP (optional, can also be configured via UI) ---
    IMAP_HOST: str = os.getenv("IMAP_HOST", "")
    IMAP_PORT: int = int(os.getenv("IMAP_PORT", "993"))
    IMAP_USER: str = os.getenv("IMAP_USER", "")
    IMAP_PASSWORD: str = os.getenv("IMAP_PASSWORD", "")
    IMAP_SSL: bool = _bool(os.getenv("IMAP_SSL"), True)

    # --- optional LLM for assisted analysis ---
    LLM_API_KEY: str = os.getenv("LLM_API_KEY", "")
    LLM_BASE_URL: str = os.getenv("LLM_BASE_URL", "")
    LLM_MODEL: str = os.getenv("LLM_MODEL", "")

    DEMO_MODE: bool = _bool(os.getenv("DEMO_MODE"), True)


settings = Settings()
settings.UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
