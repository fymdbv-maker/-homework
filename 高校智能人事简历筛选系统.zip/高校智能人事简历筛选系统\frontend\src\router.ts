import { createRouter, createWebHistory } from 'vue-router'

const router = createRouter({
  history: createWebHistory(),
  routes: [
    { path: '/login', name: 'login', component: () => import('./views/Login.vue') },
    {
      path: '/',
      component: () => import('./views/Layout.vue'),
      redirect: '/dashboard',
      children: [
        { path: 'dashboard', name: 'dashboard', component: () => import('./views/Dashboard.vue'), meta: { title: '首页仪表盘' } },
        { path: 'resumes', name: 'resumes', component: () => import('./views/ResumeList.vue'), meta: { title: '简历管理' } },
        { path: 'resumes/:id', name: 'resume-detail', component: () => import('./views/ResumeDetail.vue'), meta: { title: '简历详情' } },
        { path: 'screening', name: 'screening', component: () => import('./views/Screening.vue'), meta: { title: '智能筛选' } },
        { path: 'workbench', name: 'workbench', component: () => import('./views/Workbench.vue'), meta: { title: '人事筛选工作台' } },
        { path: 'email', name: 'email', component: () => import('./views/EmailImport.vue'), meta: { title: '邮箱简历导入' } },
        { path: 'rules', name: 'rules', component: () => import('./views/Rules.vue'), meta: { title: '岗位规则管理' } },
        { path: 'settings', name: 'settings', component: () => import('./views/Settings.vue'), meta: { title: '系统设置与审计' } },
      ],
    },
  ],
})

router.beforeEach((to) => {
  const token = localStorage.getItem('token')
  if (to.path !== '/login' && !token) return '/login'
  if (to.path === '/login' && token) return '/dashboard'
})

export default router
