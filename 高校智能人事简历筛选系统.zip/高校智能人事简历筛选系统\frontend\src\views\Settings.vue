<template>
  <div>
    <el-tabs v-model="tab">
      <el-tab-pane label="用户与角色" name="users">
        <el-card shadow="never">
          <template #header>
            <div class="card-header">
              <span class="title">用户管理</span>
              <el-button v-if="isAdmin" size="small" type="primary" @click="openUser()">新增用户</el-button>
            </div>
          </template>
          <el-alert v-if="!isAdmin" type="info" :closable="false" title="仅管理员可查看用户列表" style="margin-bottom: 12px" />
          <el-table v-if="isAdmin" :data="users" size="small">
            <el-table-column prop="id" label="ID" width="60" />
            <el-table-column prop="username" label="用户名" width="120" />
            <el-table-column prop="display_name" label="姓名" width="120" />
            <el-table-column label="角色" width="100">
              <template #default="{ row }">
                <el-tag size="small" :type="{ admin: 'danger', hr: 'primary', viewer: 'info' }[row.role]">{{ { admin: '管理员', hr: '人事专员', viewer: '只读用户' }[row.role] }}</el-tag>
              </template>
            </el-table-column>
            <el-table-column label="状态" width="80">
              <template #default="{ row }"><el-tag size="small" :type="row.active ? 'success' : 'info'">{{ row.active ? '启用' : '停用' }}</el-tag></template>
            </el-table-column>
            <el-table-column label="创建时间" width="160"><template #default="{ row }">{{ fmtTime(row.created_at) }}</template></el-table-column>
            <el-table-column label="操作" width="80">
              <template #default="{ row }"><el-button text type="primary" size="small" @click="openUser(row)">编辑</el-button></template>
            </el-table-column>
          </el-table>
        </el-card>
      </el-tab-pane>

      <el-tab-pane label="操作日志" name="logs">
        <el-card shadow="never">
          <div class="toolbar">
            <el-input v-model="logAction" placeholder="按操作类型搜索，如 login / upload / review" clearable style="width: 280px" @change="loadLogs(1)" />
            <el-button type="primary" @click="loadLogs(1)">查询</el-button>
          </div>
          <el-table :data="logs" v-loading="logsLoading" size="small" style="margin-top: 12px">
            <el-table-column prop="id" label="ID" width="70" />
            <el-table-column prop="username" label="操作人" width="100" />
            <el-table-column prop="action" label="操作" width="140" />
            <el-table-column prop="target_type" label="对象类型" width="110" />
            <el-table-column prop="target_id" label="对象ID" width="80" />
            <el-table-column prop="detail" label="详情" min-width="220" show-overflow-tooltip />
            <el-table-column prop="ip" label="IP" width="120" />
            <el-table-column label="时间" width="160"><template #default="{ row }">{{ fmtTime(row.created_at) }}</template></el-table-column>
          </el-table>
          <el-pagination style="margin-top: 12px; justify-content: flex-end" background layout="total, prev, pager, next"
            :total="logsTotal" v-model:current-page="logPage" :page-size="20" @current-change="loadLogs()" />
        </el-card>
      </el-tab-pane>

      <el-tab-pane label="系统设置" name="settings">
        <el-card shadow="never">
          <template #header>
            <div class="card-header">
              <span class="title">系统参数（敏感值自动脱敏显示）</span>
              <el-button v-if="isAdmin" size="small" type="primary" @click="openSetting()">新增参数</el-button>
            </div>
          </template>
          <el-table v-if="isAdmin" :data="settingsRows" size="small">
            <el-table-column prop="key" label="键" width="220" />
            <el-table-column prop="value" label="值" min-width="200" show-overflow-tooltip />
            <el-table-column prop="description" label="说明" min-width="160" show-overflow-tooltip />
            <el-table-column label="操作" width="80">
              <template #default="{ row }"><el-button text type="primary" size="small" @click="openSetting(row)">编辑</el-button></template>
            </el-table-column>
          </el-table>
          <el-alert v-else type="info" :closable="false" title="仅管理员可查看系统设置" />
        </el-card>
      </el-tab-pane>

      <el-tab-pane label="模型配置" name="model">
        <el-card shadow="never">
          <template #header><span class="title">AI 模型配置状态</span></template>
          <el-alert :type="modelCfg.configured ? 'success' : 'info'" :closable="false" style="margin-bottom: 12px" :title="modelCfg.note || ''" />
          <el-descriptions :column="1" border>
            <el-descriptions-item label="是否已配置 LLM">
              <el-tag :type="modelCfg.configured ? 'success' : 'info'">{{ modelCfg.configured ? '已配置' : '未配置（使用内置规则引擎）' }}</el-tag>
            </el-descriptions-item>
            <el-descriptions-item label="Base URL">{{ modelCfg.base_url || '—' }}</el-descriptions-item>
            <el-descriptions-item label="模型">{{ modelCfg.model || '—' }}</el-descriptions-item>
            <el-descriptions-item label="配置方式">在后端 .env 中设置 LLM_API_KEY / LLM_BASE_URL / LLM_MODEL，密钥不会在前端显示</el-descriptions-item>
          </el-descriptions>
        </el-card>
      </el-tab-pane>
    </el-tabs>

    <el-dialog v-model="userDialog" :title="userForm.id ? '编辑用户' : '新增用户'" width="440px">
      <el-form :model="userForm" label-width="90px">
        <el-form-item label="用户名" required><el-input v-model="userForm.username" :disabled="!!userForm.id" /></el-form-item>
        <el-form-item label="姓名"><el-input v-model="userForm.display_name" /></el-form-item>
        <el-form-item label="角色">
          <el-select v-model="userForm.role" style="width: 100%">
            <el-option label="管理员" value="admin" /><el-option label="人事专员" value="hr" /><el-option label="只读用户" value="viewer" />
          </el-select>
        </el-form-item>
        <el-form-item :label="userForm.id ? '重置密码' : '密码'" :required="!userForm.id">
          <el-input v-model="userForm.password" type="password" show-password :placeholder="userForm.id ? '留空则不修改' : ''" />
        </el-form-item>
        <el-form-item v-if="userForm.id" label="启用"><el-switch v-model="userForm.active" /></el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="userDialog = false">取消</el-button>
        <el-button type="primary" @click="saveUser">保存</el-button>
      </template>
    </el-dialog>

    <el-dialog v-model="settingDialog" title="系统参数" width="480px">
      <el-form :model="settingForm" label-width="90px">
        <el-form-item label="键" required><el-input v-model="settingForm.key" :disabled="settingForm.edit" /></el-form-item>
        <el-form-item label="值"><el-input v-model="settingForm.value" placeholder="显示为 ****** 时留空表示不修改" /></el-form-item>
        <el-form-item label="说明"><el-input v-model="settingForm.description" /></el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="settingDialog = false">取消</el-button>
        <el-button type="primary" @click="saveSetting">保存</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { computed, onMounted, reactive, ref } from 'vue'
import { ElMessage } from 'element-plus'
import api from '../api'

const tab = ref('users')
const users = ref<any[]>([])
const logs = ref<any[]>([])
const logsLoading = ref(false)
const logsTotal = ref(0)
const logPage = ref(1)
const logAction = ref('')
const settingsRows = ref<any[]>([])
const modelCfg = reactive<any>({})

const userDialog = ref(false)
const settingDialog = ref(false)
const userForm = reactive<any>({ id: null, username: '', display_name: '', role: 'hr', password: '', active: true })
const settingForm = reactive<any>({ key: '', value: '', description: '', edit: false })

const isAdmin = computed(() => {
  try { return JSON.parse(localStorage.getItem('user') || 'null')?.role === 'admin' } catch { return false }
})
const fmtTime = (t: string) => (t ? new Date(t).toLocaleString('zh-CN') : '—')

async function loadUsers() {
  if (!isAdmin.value) return
  const { data } = await api.get('/users')
  users.value = data
}

async function loadLogs(page?: number) {
  if (page) logPage.value = page
  logsLoading.value = true
  try {
    const { data } = await api.get('/audit-logs', { params: { page: logPage.value, page_size: 20, action: logAction.value } })
    logs.value = data.items
    logsTotal.value = data.total
  } finally {
    logsLoading.value = false
  }
}

async function loadSettings() {
  if (!isAdmin.value) return
  const { data } = await api.get('/settings')
  settingsRows.value = data
}

async function loadModelCfg() {
  const { data } = await api.get('/model-config')
  Object.assign(modelCfg, data)
}

function openUser(row?: any) {
  Object.assign(userForm, row
    ? { id: row.id, username: row.username, display_name: row.display_name, role: row.role, password: '', active: row.active }
    : { id: null, username: '', display_name: '', role: 'hr', password: '', active: true })
  userDialog.value = true
}

async function saveUser() {
  if (!userForm.username || (!userForm.id && !userForm.password)) {
    ElMessage.warning('请填写用户名和密码')
    return
  }
  if (userForm.id) {
    const body: any = { display_name: userForm.display_name, role: userForm.role, active: userForm.active }
    if (userForm.password) body.password = userForm.password
    await api.put(`/users/${userForm.id}`, body)
  } else {
    await api.post('/users', { username: userForm.username, password: userForm.password, display_name: userForm.display_name, role: userForm.role })
  }
  ElMessage.success('用户已保存')
  userDialog.value = false
  loadUsers()
}

function openSetting(row?: any) {
  Object.assign(settingForm, row ? { key: row.key, value: '', description: row.description, edit: true } : { key: '', value: '', description: '', edit: false })
  settingDialog.value = true
}

async function saveSetting() {
  if (!settingForm.key) {
    ElMessage.warning('请填写键名')
    return
  }
  await api.put('/settings', { key: settingForm.key, value: settingForm.value, description: settingForm.description })
  ElMessage.success('参数已保存')
  settingDialog.value = false
  loadSettings()
}

onMounted(() => {
  loadUsers()
  loadLogs()
  loadSettings()
  loadModelCfg()
})
</script>

<style scoped>
.title { font-size: 15px; font-weight: 600; }
.card-header { display: flex; justify-content: space-between; align-items: center; }
.toolbar { display: flex; gap: 10px; }
</style>
