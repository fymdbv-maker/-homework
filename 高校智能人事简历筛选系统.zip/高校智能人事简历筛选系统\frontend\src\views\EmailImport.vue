<template>
  <div>
    <el-card shadow="never">
      <template #header><span class="title">邮箱简历导入（IMAP）</span></template>
      <el-alert v-if="config.demo_mode" type="warning" :closable="false" style="margin-bottom: 16px"
        title="当前为演示模式：尚未配置真实 IMAP 邮箱，无法进行真实同步。请在下方填写邮箱服务器信息（管理员），或在后端 .env 中配置 IMAP_HOST / IMAP_USER / IMAP_PASSWORD。" />
      <el-alert v-else type="success" :closable="false" style="margin-bottom: 16px" title="已配置真实邮箱，可执行同步。" />

      <el-form :model="form" label-width="110px" style="max-width: 560px">
        <el-form-item label="IMAP 服务器"><el-input v-model="form.host" placeholder="如 imap.qq.com" /></el-form-item>
        <el-form-item label="端口"><el-input-number v-model="form.port" :min="1" :max="65535" /></el-form-item>
        <el-form-item label="邮箱账号"><el-input v-model="form.username" placeholder="hr@example.edu.cn" /></el-form-item>
        <el-form-item label="密码/授权码">
          <el-input v-model="form.password" type="password" show-password :placeholder="config.has_password ? '已保存（留空则不修改）' : '请输入密码或客户端授权码'" />
        </el-form-item>
        <el-form-item label="使用 SSL"><el-switch v-model="form.use_ssl" /></el-form-item>
        <el-form-item label="启用同步"><el-switch v-model="form.enabled" /></el-form-item>
        <el-form-item>
          <el-button type="primary" :loading="saving" @click="save">保存配置</el-button>
          <el-button type="success" :loading="syncing" :disabled="config.demo_mode" @click="sync">手动同步</el-button>
        </el-form-item>
      </el-form>

      <el-descriptions v-if="config.last_sync_at" :column="3" border size="small" style="max-width: 760px">
        <el-descriptions-item label="上次同步时间">{{ fmtTime(config.last_sync_at) }}</el-descriptions-item>
        <el-descriptions-item label="同步结果">
          <el-tag size="small" :type="config.last_sync_status === 'success' ? 'success' : 'danger'">{{ config.last_sync_status || '—' }}</el-tag>
        </el-descriptions-item>
        <el-descriptions-item label="同步信息">{{ config.last_sync_message || '—' }}</el-descriptions-item>
      </el-descriptions>
    </el-card>

    <el-card shadow="never" style="margin-top: 16px">
      <template #header>
        <div class="card-header">
          <span class="title">导入日志（含重复附件识别）</span>
          <el-button size="small" @click="loadLogs()">刷新</el-button>
        </div>
      </template>
      <el-table :data="logs" v-loading="logsLoading" size="small">
        <el-table-column prop="id" label="ID" width="60" />
        <el-table-column label="来源" width="80">
          <template #default="{ row }"><el-tag size="small" :type="row.source === 'email' ? 'warning' : 'info'">{{ row.source === 'email' ? '邮箱' : '上传' }}</el-tag></template>
        </el-table-column>
        <el-table-column prop="reference" label="邮件/文件引用" min-width="160" show-overflow-tooltip />
        <el-table-column prop="attachment_name" label="附件名" min-width="140" show-overflow-tooltip />
        <el-table-column label="状态" width="90">
          <template #default="{ row }">
            <el-tag size="small" :type="{ success: 'success', duplicate: 'warning', failed: 'danger' }[row.status] || 'info'">
              {{ { success: '成功', duplicate: '重复跳过', failed: '失败' }[row.status] || row.status }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="detail" label="详情" min-width="160" show-overflow-tooltip />
        <el-table-column label="时间" width="160"><template #default="{ row }">{{ fmtTime(row.created_at) }}</template></el-table-column>
      </el-table>
      <el-pagination style="margin-top: 12px; justify-content: flex-end" background layout="total, prev, pager, next"
        :total="logsTotal" v-model:current-page="logPage" :page-size="20" @current-change="loadLogs()" />
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { onMounted, reactive, ref } from 'vue'
import { ElMessage } from 'element-plus'
import api from '../api'

const config = reactive<any>({ demo_mode: true })
const form = reactive({ host: '', port: 993, username: '', password: '', use_ssl: true, enabled: true })
const saving = ref(false)
const syncing = ref(false)
const logs = ref<any[]>([])
const logsLoading = ref(false)
const logsTotal = ref(0)
const logPage = ref(1)

const fmtTime = (t: string) => (t ? new Date(t).toLocaleString('zh-CN') : '—')

async function loadConfig() {
  const { data } = await api.get('/email/config')
  Object.assign(config, data)
  form.host = data.host || ''
  form.port = data.port || 993
  form.username = data.username || ''
  form.use_ssl = data.use_ssl
  form.enabled = data.enabled
}

async function save() {
  saving.value = true
  try {
    const { data } = await api.put('/email/config', form)
    Object.assign(config, data)
    form.password = ''
    ElMessage.success('邮箱配置已保存')
  } finally {
    saving.value = false
  }
}

async function sync() {
  syncing.value = true
  try {
    const { data } = await api.post('/email/sync')
    if (data.ok) ElMessage.success(`同步完成：${JSON.stringify(data.stats)}`)
    else ElMessage.warning(data.message)
    loadConfig()
    loadLogs()
  } finally {
    syncing.value = false
  }
}

async function loadLogs() {
  logsLoading.value = true
  try {
    const { data } = await api.get('/email/logs', { params: { page: logPage.value, page_size: 20 } })
    logs.value = data.items
    logsTotal.value = data.total
  } finally {
    logsLoading.value = false
  }
}

onMounted(() => {
  loadConfig()
  loadLogs()
})
</script>

<style scoped>
.title { font-size: 16px; font-weight: 600; }
.card-header { display: flex; justify-content: space-between; align-items: center; }
</style>
