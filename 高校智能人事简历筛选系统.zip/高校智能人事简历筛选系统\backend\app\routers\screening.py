import csv
import io

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session

from ..database import get_db
from ..deps import audit, get_current_user, require_role
from ..models import Resume, Rule, ScreeningResult, User
from ..schemas import ReviewRequest, RunScreeningRequest, ScreeningResultOut
from ..services.screening_engine import run_screening

router = APIRouter(prefix="/api/screening", tags=["screening"])


@router.post("/run", response_model=list[ScreeningResultOut])
def run(
    body: RunScreeningRequest,
    request: Request,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    rule = db.get(Rule, body.rule_id)
    if not rule or not rule.enabled:
        raise HTTPException(404, "筛选规则不存在或已停用")

    q = db.query(Resume)
    if body.resume_ids:
        q = q.filter(Resume.id.in_(body.resume_ids))
    resumes = q.all()
    results: list[ScreeningResult] = []
    for resume in resumes:
        existing = (
            db.query(ScreeningResult)
            .filter(ScreeningResult.resume_id == resume.id, ScreeningResult.rule_id == rule.id)
            .first()
        )
        if existing and not body.rerun:
            continue
        output = run_screening(resume, rule)
        if existing:
            sr = existing
        else:
            sr = ScreeningResult(resume_id=resume.id, rule_id=rule.id)
            db.add(sr)
        sr.rule_version = rule.version
        sr.position_name = rule.position.name if rule.position else ""
        sr.hard_checks = output["hard_checks"]
        sr.qualification = output["qualification"]
        sr.score = output["score"]
        sr.score_breakdown = output["score_breakdown"]
        sr.suggestion = output["suggestion"]
        if body.rerun:
            sr.status = "pending"
            sr.reviewer = ""
            sr.review_note = ""
            sr.reviewed_at = None
        results.append(sr)
    audit(db, user, "run_screening", "rule", rule.id, f"规则 {rule.name}，处理 {len(results)} 份简历", request)
    db.commit()
    for r in results:
        db.refresh(r)
    return [ScreeningResultOut.model_validate(r) for r in results]


@router.get("/results", response_model=dict)
def list_results(
    page: int = Query(1, ge=1),
    page_size: int = Query(10, ge=1, le=200),
    position: str = "",
    qualification: str = "",
    status: str = "",
    education: str = "",
    school_tier: str = "",
    is_fresh: str = "",
    major_match: str = "",   # "yes" / "no" — based on score breakdown item 专业匹配
    keyword: str = "",
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    q = db.query(ScreeningResult).join(Resume, Resume.id == ScreeningResult.resume_id)
    if position:
        q = q.filter(ScreeningResult.position_name == position)
    if qualification:
        q = q.filter(ScreeningResult.qualification == qualification)
    if status:
        q = q.filter(ScreeningResult.status == status)
    if education:
        q = q.filter(Resume.education == education)
    if school_tier:
        q = q.filter(Resume.school_tier == school_tier)
    if is_fresh:
        q = q.filter(Resume.is_fresh == is_fresh)
    if keyword:
        like = f"%{keyword}%"
        q = q.filter((Resume.name.like(like)) | (Resume.school.like(like)) | (Resume.major.like(like)))
    rows = q.order_by(ScreeningResult.created_at.desc()).all()

    if major_match in {"yes", "no"}:
        def matched(r: ScreeningResult) -> bool:
            for b in r.score_breakdown or []:
                if b.get("item") == "专业匹配":
                    return (b.get("points") or 0) > 0
            return False
        rows = [r for r in rows if matched(r) == (major_match == "yes")]

    total = len(rows)
    page_rows = rows[(page - 1) * page_size: page * page_size]
    resume_map = {r.resume_id: r.resume for r in page_rows}
    items = []
    for r in page_rows:
        d = ScreeningResultOut.model_validate(r).model_dump()
        resume = resume_map.get(r.resume_id)
        d["resume"] = {
            "id": resume.id, "name": resume.name, "education": resume.education,
            "school": resume.school, "school_tier": resume.school_tier, "major": resume.major,
            "is_fresh": resume.is_fresh, "age": resume.age,
            "political_status": resume.political_status, "work_years": resume.work_years,
            "parse_status": resume.parse_status,
        } if resume else None
        items.append(d)
    return {"total": total, "items": items}


@router.post("/results/{result_id}/review", response_model=ScreeningResultOut)
def review(
    result_id: int,
    body: ReviewRequest,
    request: Request,
    db: Session = Depends(get_db),
    user: User = Depends(require_role("admin", "hr")),
):
    if body.status not in {"approved", "rejected", "pending"}:
        raise HTTPException(400, "无效的审核状态")
    sr = db.get(ScreeningResult, result_id)
    if not sr:
        raise HTTPException(404, "筛选结果不存在")
    from datetime import datetime
    sr.status = body.status
    sr.reviewer = user.display_name or user.username
    sr.review_note = body.review_note
    sr.reviewed_at = datetime.utcnow() if body.status != "pending" else None
    audit(db, user, "review_result", "screening_result", sr.id, f"审核为 {body.status}", request)
    db.commit()
    db.refresh(sr)
    return ScreeningResultOut.model_validate(sr)


@router.post("/results/batch-review")
def batch_review(
    ids: list[int],
    request: Request,
    status: str = Query("approved"),
    note: str = "",
    db: Session = Depends(get_db),
    user: User = Depends(require_role("admin", "hr")),
):
    if status not in {"approved", "rejected", "pending"}:
        raise HTTPException(400, "无效的审核状态")
    from datetime import datetime
    rows = db.query(ScreeningResult).filter(ScreeningResult.id.in_(ids)).all()
    for sr in rows:
        sr.status = status
        sr.reviewer = user.display_name or user.username
        sr.review_note = note
        sr.reviewed_at = datetime.utcnow() if status != "pending" else None
    audit(db, user, "batch_review", "screening_result", ",".join(map(str, ids)), f"批量审核为 {status}", request)
    db.commit()
    return {"ok": True, "count": len(rows)}


@router.get("/export")
def export_csv(
    position: str = "",
    qualification: str = "",
    status: str = "",
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    q = db.query(ScreeningResult).join(Resume, Resume.id == ScreeningResult.resume_id)
    if position:
        q = q.filter(ScreeningResult.position_name == position)
    if qualification:
        q = q.filter(ScreeningResult.qualification == qualification)
    if status:
        q = q.filter(ScreeningResult.status == status)
    rows = q.order_by(ScreeningResult.created_at.desc()).all()

    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(["姓名", "应聘岗位", "学历", "毕业院校", "专业", "应届", "年龄", "硬性核验", "综合评分", "审核状态", "审核人", "审核备注"])
    qual_map = {"qualified": "符合", "unqualified": "不符合", "needs_review": "待核实"}
    status_map = {"pending": "待审核", "approved": "已通过", "rejected": "未通过"}
    fresh_map = {"fresh": "应届", "not_fresh": "非应届", "unknown": "待核实"}
    for r in rows:
        resume = r.resume
        writer.writerow([
            resume.name or "待核实", r.position_name, resume.education or "待核实",
            resume.school or "待核实", resume.major or "待核实",
            fresh_map.get(resume.is_fresh, "待核实"),
            resume.age if resume.age is not None else "待核实",
            qual_map.get(r.qualification, r.qualification), r.score,
            status_map.get(r.status, r.status), r.reviewer, r.review_note,
        ])
    content = "﻿" + buf.getvalue()
    audit(db, user, "export_results", "screening_result", "", f"导出 {len(rows)} 条")
    db.commit()
    return StreamingResponse(
        iter([content.encode("utf-8")]),
        media_type="text/csv; charset=utf-8",
        headers={"Content-Disposition": "attachment; filename=screening_results.csv"},
    )
