"""Initialize the database with demo accounts, positions, rules and sample resumes.

Usage:  python init_db.py
Idempotent: safe to run repeatedly — existing data is kept.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from app.database import Base, SessionLocal, engine  # noqa: E402
from app.models import Position, Resume, Rule, SystemSetting, User  # noqa: E402
from app.security import hash_password  # noqa: E402
from app.services.resume_parser import parse_fields  # noqa: E402

DEMO_RESUMES = [
    """个人简历
姓名：王丽华
性别：女
出生日期：1990年5月
电话：13812345678
邮箱：wanglihua@example.com
政治面貌：中共党员
户籍：上海
学历：硕士研究生  华东师范大学 教育学专业
毕业时间：2015年6月
工作经验：8年高校学生工作经验，曾任辅导员、班主任
求职意向：辅导员
""",
    """个人简历
姓名：张志强
性别：男
出生日期：1998年3月
电话：13987654321
邮箱：zhangzq@example.com
政治面貌：共青团员
学历：硕士研究生  上海大学 计算机科学与技术专业
毕业时间：2026年6月 应届毕业生
求职意向：专任教师
""",
    """应聘岗位：辅导员
姓名：李明
性别：男
年龄：35岁
电话：13711112222
学历：本科  苏州大学 心理学专业
毕业时间：2013年6月
工作经验：10年企业人力资源经验
政治面貌：群众
户籍：江苏苏州，持有上海居住证（有效）
""",
    """求职简历
姓名：陈思远
性别：男
出生日期：1985年11月
电话：13633334444
邮箱：chensy@example.com
政治面貌：群众
户籍：浙江杭州
学历：博士研究生  复旦大学 物理专业
毕业时间：2012年6月
工作经验：11年高校教学经验
求职意向：专任教师
""",
    """个人简历
姓名：赵晓燕
性别：女
出生日期：1999年8月
电话：13555556666
政治面貌：中共党员
学历：硕士研究生  上海交通大学 思想政治教育专业
毕业时间：2026年6月 应届毕业生
求职意向：辅导员
""",
]


def seed():
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    try:
        # --- users ---
        if not db.query(User).filter(User.username == "admin").first():
            db.add_all([
                User(username="admin", password_hash=hash_password("admin123"),
                     display_name="系统管理员", role="admin"),
                User(username="hr", password_hash=hash_password("hr123456"),
                     display_name="人事处张老师", role="hr"),
                User(username="viewer", password_hash=hash_password("view123"),
                     display_name="查阅账号", role="viewer"),
            ])
            print("已创建演示账号: admin/admin123, hr/hr123456, viewer/view123")

        # --- positions ---
        pos_counselor = db.query(Position).filter(Position.code == "FDY").first()
        if not pos_counselor:
            pos_counselor = Position(
                name="辅导员", code="FDY", department="学生工作部",
                description="负责学生思想政治教育与日常管理。要求：中共党员（含预备党员）、硕士及以上学历、40 周岁以下；非应届生需上海户籍或有效上海居住证。",
            )
            db.add(pos_counselor)
        pos_teacher = db.query(Position).filter(Position.code == "ZJJS").first()
        if not pos_teacher:
            pos_teacher = Position(
                name="专任教师", code="ZJJS", department="教务处",
                description="承担课程教学与科研工作。要求：硕士及以上学历，专业匹配。",
            )
            db.add(pos_teacher)
        db.flush()

        # --- rules ---
        if not db.query(Rule).filter(Rule.name == "辅导员招聘规则").first():
            db.add(Rule(
                position_id=pos_counselor.id, name="辅导员招聘规则", version=1,
                created_by="system", change_note="初始版本",
                config={
                    "min_education": "硕士",
                    "accepted_majors": ["教育学", "心理学", "思想政治教育", "马克思主义"],
                    "major_match_required": False,
                    "max_age": 40,
                    "require_party_member": True,
                    "non_fresh_requires": "shanghai_hukou_or_residence_permit",
                    "fresh_only": False,
                    "min_work_years": 0,
                    "scoring": {
                        "school_tier": {"985": 20, "211": 15, "普通本科": 8, "其他": 4},
                        "education": {"博士": 25, "硕士": 18, "本科": 10, "大专": 4},
                        "major_match": 20,
                        "fresh_bonus": 10,
                        "work_years": {"per_year": 2, "max": 15},
                        "related_experience_bonus": 10,
                    },
                },
            ))
        if not db.query(Rule).filter(Rule.name == "专任教师招聘规则").first():
            db.add(Rule(
                position_id=pos_teacher.id, name="专任教师招聘规则", version=1,
                created_by="system", change_note="初始版本",
                config={
                    "min_education": "硕士",
                    "accepted_majors": ["计算机", "物理", "数学", "教育学"],
                    "major_match_required": True,
                    "max_age": None,
                    "require_party_member": False,
                    "non_fresh_requires": None,
                    "fresh_only": False,
                    "min_work_years": 0,
                    "scoring": {
                        "school_tier": {"985": 20, "211": 15, "普通本科": 8, "其他": 4},
                        "education": {"博士": 25, "硕士": 18, "本科": 10, "大专": 4},
                        "major_match": 25,
                        "fresh_bonus": 5,
                        "work_years": {"per_year": 2, "max": 15},
                        "related_experience_bonus": 0,
                    },
                },
            ))
            print("已创建岗位与规则：辅导员、专任教师")

        # --- demo resumes (synthetic text files) ---
        if db.query(Resume).count() == 0:
            import hashlib
            upload_dir = Path(__file__).parent / "uploads"
            upload_dir.mkdir(exist_ok=True)
            for i, text in enumerate(DEMO_RESUMES, 1):
                data = text.encode("utf-8")
                h = hashlib.sha256(data).hexdigest()
                fname = f"demo_resume_{i}.txt"
                dest = upload_dir / f"{h[:16]}.txt"
                dest.write_bytes(data)
                fields, sources, _ = parse_fields(text)
                r = Resume(
                    filename=fname, stored_path=str(dest), file_type=".txt",
                    file_hash=h, file_size=len(data), source="upload",
                    raw_text=text, field_sources=sources, parse_status="parsed",
                )
                for k, v in fields.items():
                    if hasattr(r, k):
                        setattr(r, k, v)
                db.add(r)
            print(f"已导入 {len(DEMO_RESUMES)} 份演示简历")

        # --- default settings ---
        for key, value, desc in [
            ("school_tier_custom", "", "自定义学校层次映射（JSON，可选）"),
            ("llm_assist_note", "AI 仅提供辅助分析建议，不构成录用决定", "AI 辅助说明"),
        ]:
            if not db.get(SystemSetting, key):
                db.add(SystemSetting(key=key, value=value, description=desc))

        db.commit()
        print("数据库初始化完成。")
    finally:
        db.close()


if __name__ == "__main__":
    seed()
