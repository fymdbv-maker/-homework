from fastapi import APIRouter, Depends, HTTPException, Query, Request
from sqlalchemy.orm import Session

from ..config import settings
from ..database import get_db
from ..deps import audit, get_current_user, require_role
from ..models import AuditLog, SystemSetting, User
from ..schemas import AuditLogOut, SettingIn, SettingOut, UserCreate, UserOut, UserUpdate
from ..security import hash_password

router = APIRouter(prefix="/api", tags=["system"])


# ---------- users ----------
@router.get("/users", response_model=list[UserOut])
def list_users(db: Session = Depends(get_db), user: User = Depends(require_role("admin"))):
    return db.query(User).order_by(User.id).all()


@router.post("/users", response_model=UserOut)
def create_user(
    body: UserCreate, request: Request,
    db: Session = Depends(get_db), user: User = Depends(require_role("admin")),
):
    if db.query(User).filter(User.username == body.username).first():
        raise HTTPException(400, "用户名已存在")
    if body.role not in {"admin", "hr", "viewer"}:
        raise HTTPException(400, "无效角色")
    u = User(
        username=body.username, password_hash=hash_password(body.password),
        display_name=body.display_name or body.username, role=body.role,
    )
    db.add(u)
    db.flush()
    audit(db, user, "create_user", "user", u.id, f"创建用户 {u.username}({u.role})", request)
    db.commit()
    db.refresh(u)
    return u


@router.put("/users/{user_id}", response_model=UserOut)
def update_user(
    user_id: int, body: UserUpdate, request: Request,
    db: Session = Depends(get_db), user: User = Depends(require_role("admin")),
):
    u = db.get(User, user_id)
    if not u:
        raise HTTPException(404, "用户不存在")
    data = body.model_dump(exclude_unset=True)
    if "password" in data and data["password"]:
        u.password_hash = hash_password(data.pop("password"))
    data.pop("password", None)
    if "role" in data and data["role"] not in {"admin", "hr", "viewer"}:
        raise HTTPException(400, "无效角色")
    for k, v in data.items():
        if v is not None:
            setattr(u, k, v)
    audit(db, user, "update_user", "user", u.id, f"更新用户 {u.username}", request)
    db.commit()
    db.refresh(u)
    return u


# ---------- audit logs ----------
@router.get("/audit-logs", response_model=dict)
def audit_logs(
    page: int = Query(1, ge=1), page_size: int = Query(20, ge=1, le=100),
    action: str = "",
    db: Session = Depends(get_db), user: User = Depends(require_role("admin")),
):
    q = db.query(AuditLog).order_by(AuditLog.created_at.desc())
    if action:
        q = q.filter(AuditLog.action.like(f"%{action}%"))
    total = q.count()
    rows = q.offset((page - 1) * page_size).limit(page_size).all()
    return {"total": total, "items": [AuditLogOut.model_validate(r) for r in rows]}


# ---------- system settings ----------
MASKED_KEYS = ("password", "secret", "key", "token")


@router.get("/settings", response_model=list[SettingOut])
def list_settings(db: Session = Depends(get_db), user: User = Depends(require_role("admin"))):
    rows = db.query(SystemSetting).order_by(SystemSetting.key).all()
    out = []
    for r in rows:
        item = SettingOut.model_validate(r)
        if any(k in r.key.lower() for k in MASKED_KEYS) and item.value:
            item.value = "******"
        out.append(item)
    return out


@router.put("/settings", response_model=SettingOut)
def put_setting(
    body: SettingIn, request: Request,
    db: Session = Depends(get_db), user: User = Depends(require_role("admin")),
):
    row = db.get(SystemSetting, body.key)
    if not row:
        row = SystemSetting(key=body.key)
        db.add(row)
    if body.value != "******":
        row.value = body.value
    row.description = body.description
    audit(db, user, "put_setting", "setting", body.key, body.description, request)
    db.commit()
    db.refresh(row)
    out = SettingOut.model_validate(row)
    if any(k in row.key.lower() for k in MASKED_KEYS) and out.value:
        out.value = "******"
    return out


@router.get("/model-config")
def model_config(user: User = Depends(get_current_user)):
    """Show whether an LLM is configured — never exposes the key."""
    return {
        "configured": bool(settings.LLM_API_KEY and settings.LLM_BASE_URL),
        "base_url": settings.LLM_BASE_URL if settings.LLM_API_KEY else "",
        "model": settings.LLM_MODEL if settings.LLM_API_KEY else "",
        "note": "AI 仅用于辅助分析与可解释建议；未配置时系统自动使用规则引擎。",
    }
