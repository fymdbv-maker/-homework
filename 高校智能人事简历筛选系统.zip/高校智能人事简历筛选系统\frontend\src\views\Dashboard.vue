<template>
  <div>
    <el-row :gutter="16">
      <el-col :xs="12" :sm="8" :md="4" v-for="c in cards" :key="c.label">
        <el-card shadow="hover" class="stat-card" @click="c.to && $router.push(c.to)">
          <div class="stat-value" :style="{ color: c.color }">{{ c.value }}</div>
          <div class="stat-label">{{ c.label }}</div>
        </el-card>
      </el-col>
    </el-row>

    <el-row :gutter="16" style="margin-top: 16px">
      <el-col :xs="24" :md="12">
        <el-card shadow="never">
          <template #header>
            <div class="card-header">
              <span>最近导入的简历</span>
              <el-button text type="primary" @click="$router.push('/resumes')">全部简历</el-button>
            </div>
          </template>
          <el-table :data="stats.recent_resumes" size="small" v-loading="loading">
            <el-table-column prop="name" label="姓名" width="90">
              <template #default="{ row }">{{ show(row.name) }}</template>
            </el-table-column>
            <el-table-column prop="target_position" label="应聘岗位" show-overflow-tooltip>
              <template #default="{ row }">{{ show(row.target_position) }}</template>
            </el-table-column>
            <el-table-column prop="education" label="学历" width="70">
              <template #default="{ row }">{{ show(row.education) }}</template>
            </el-table-column>
            <el-table-column label="来源" width="70">
              <template #default="{ row }">
                <el-tag size="small" :type="row.source === 'email' ? 'warning' : 'info'">
                  {{ row.source === 'email' ? '邮箱' : '上传' }}
                </el-tag>
              </template>
            </el-table-column>
            <el-table-column label="解析状态" width="90">
              <template #default="{ row }">
                <el-tag size="small" :type="parseStatusMap[row.parse_status]?.type">{{ parseStatusMap[row.parse_status]?.label }}</el-tag>
              </template>
            </el-table-column>
            <el-table-column label="操作" width="70">
              <template #default="{ row }">
                <el-button text type="primary" size="small" @click="$router.push(`/resumes/${row.id}`)">详情</el-button>
              </template>
            </el-table-column>
          </el-table>
        </el-card>
      </el-col>

      <el-col :xs="24" :md="12">
        <el-card shadow="never">
          <template #header>
            <div class="card-header">
              <span>最近筛选结果</span>
              <el-button text type="primary" @click="$router.push('/workbench')">前往工作台</el-button>
            </div>
          </template>
          <el-table :data="stats.recent_results" size="small" v-loading="loading">
            <el-table-column prop="resume_name" label="姓名" width="90">
              <template #default="{ row }">{{ show(row.resume_name) }}</template>
            </el-table-column>
            <el-table-column prop="position_name" label="岗位" show-overflow-tooltip />
            <el-table-column label="硬性核验" width="100">
              <template #default="{ row }">
                <el-tag size="small" :type="qualMap[row.qualification]?.type">{{ qualMap[row.qualification]?.label }}</el-tag>
              </template>
            </el-table-column>
            <el-table-column prop="score" label="评分" width="70" sortable />
            <el-table-column label="审核状态" width="90">
              <template #default="{ row }">
                <el-tag size="small" :type="reviewStatusMap[row.status]?.type">{{ reviewStatusMap[row.status]?.label }}</el-tag>
              </template>
            </el-table-column>
          </el-table>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script setup lang="ts">
import { computed, onMounted, reactive, ref } from 'vue'
import api from '../api'
import { show, qualMap, reviewStatusMap, parseStatusMap } from '../display'

const loading = ref(false)
const stats = reactive<any>({
  total_resumes: 0, pending_parse: 0, qualified: 0,
  pending_review: 0, needs_review: 0, unqualified: 0,
  recent_resumes: [], recent_results: [],
})

const cards = computed(() => [
  { label: '简历总数', value: stats.total_resumes, color: '#1f6feb', to: '/resumes' },
  { label: '待解析', value: stats.pending_parse, color: '#909399', to: '/resumes' },
  { label: '符合条件', value: stats.qualified, color: '#67c23a', to: '/workbench' },
  { label: '待人工审核', value: stats.pending_review, color: '#e6a23c', to: '/workbench' },
  { label: '待核实条件', value: stats.needs_review, color: '#b88230', to: '/workbench' },
  { label: '不符合条件', value: stats.unqualified, color: '#f56c6c', to: '/workbench' },
])

onMounted(async () => {
  loading.value = true
  try {
    const { data } = await api.get('/dashboard/stats')
    Object.assign(stats, data)
  } finally {
    loading.value = false
  }
})
</script>

<style scoped>
.stat-card { cursor: pointer; text-align: center; margin-bottom: 12px; }
.stat-value { font-size: 28px; font-weight: 700; }
.stat-label { color: #909399; font-size: 13px; margin-top: 4px; }
.card-header { display: flex; justify-content: space-between; align-items: center; }
</style>
