from sqlalchemy import func
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from ..database import get_db
from ..deps import get_current_user
from ..models import Resume, ScreeningResult, User

router = APIRouter(prefix="/api/dashboard", tags=["dashboard"])


@router.get("/stats")
def stats(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    total = db.query(func.count(Resume.id)).scalar() or 0
    pending_parse = db.query(func.count(Resume.id)).filter(Resume.parse_status == "pending").scalar() or 0
    qualified = (
        db.query(func.count(ScreeningResult.id))
        .filter(ScreeningResult.qualification == "qualified")
        .scalar() or 0
    )
    pending_review = (
        db.query(func.count(ScreeningResult.id))
        .filter(ScreeningResult.status == "pending")
        .scalar() or 0
    )
    needs_review = (
        db.query(func.count(ScreeningResult.id))
        .filter(ScreeningResult.qualification == "needs_review")
        .scalar() or 0
    )
    unqualified = (
        db.query(func.count(ScreeningResult.id))
        .filter(ScreeningResult.qualification == "unqualified")
        .scalar() or 0
    )

    recent_resumes = (
        db.query(Resume).order_by(Resume.created_at.desc()).limit(8).all()
    )
    recent_results = (
        db.query(ScreeningResult, Resume.name)
        .join(Resume, Resume.id == ScreeningResult.resume_id)
        .order_by(ScreeningResult.created_at.desc())
        .limit(8)
        .all()
    )
    return {
        "total_resumes": total,
        "pending_parse": pending_parse,
        "qualified": qualified,
        "pending_review": pending_review,
        "needs_review": needs_review,
        "unqualified": unqualified,
        "recent_resumes": [
            {
                "id": r.id, "name": r.name, "target_position": r.target_position,
                "education": r.education, "school": r.school, "parse_status": r.parse_status,
                "source": r.source, "created_at": r.created_at,
            }
            for r in recent_resumes
        ],
        "recent_results": [
            {
                "id": sr.id, "resume_id": sr.resume_id, "resume_name": name,
                "position_name": sr.position_name, "qualification": sr.qualification,
                "score": sr.score, "status": sr.status, "created_at": sr.created_at,
            }
            for sr, name in recent_results
        ],
    }
