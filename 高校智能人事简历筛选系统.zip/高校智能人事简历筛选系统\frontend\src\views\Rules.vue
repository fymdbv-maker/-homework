<template>
  <div>
    <el-row :gutter="16">
      <el-col :xs="24" :md="9">
        <el-card shadow="never">
          <template #header>
            <div class="card-header">
              <span class="title">招聘岗位</span>
              <el-button size="small" type="primary" @click="openPosition()">新增岗位</el-button>
            </div>
          </template>
          <el-table :data="positions" size="small" highlight-current-row @current-change="onPickPosition">
            <el-table-column prop="name" label="岗位名称" />
            <el-table-column prop="code" label="编码" width="90" />
            <el-table-column label="状态" width="80">
              <template #default="{ row }"><el-tag size="small" :type="row.active ? 'success' : 'info'">{{ row.active ? '启用' : '停用' }}</el-tag></template>
            </el-table-column>
            <el-table-column label="操作" width="130">
              <template #default="{ row }">
                <el-button text type="primary" size="small" @click.stop="openPosition(row)">编辑</el-button>
                <el-button text :type="row.active ? 'warning' : 'success'" size="small" @click.stop="togglePosition(row)">{{ row.active ? '停用' : '启用' }}</el-button>
              </template>
            </el-table-column>
          </el-table>
        </el-card>
      </el-col>

      <el-col :xs="24" :md="15">
        <el-card shadow="never">
          <template #header>
            <div class="card-header">
              <span class="title">筛选规则{{ currentPosition ? `（${currentPosition.name}）` : '' }}</span>
              <el-button size="small" type="primary" :disabled="!currentPosition" @click="openRule()">新增规则</el-button>
            </div>
          </template>
          <el-empty v-if="!currentPosition" description="请先在左侧选择岗位" />
          <el-table v-else :data="positionRules" size="small">
            <el-table-column prop="name" label="规则名称" min-width="120" />
            <el-table-column label="版本" width="70"><template #default="{ row }">v{{ row.version }}</template></el-table-column>
            <el-table-column label="硬性条件摘要" min-width="220">
              <template #default="{ row }">{{ ruleSummary(row.config) }}</template>
            </el-table-column>
            <el-table-column label="状态" width="80">
              <template #default="{ row }"><el-tag size="small" :type="row.enabled ? 'success' : 'info'">{{ row.enabled ? '启用' : '停用' }}</el-tag></template>
            </el-table-column>
            <el-table-column label="修改人/时间" width="150">
              <template #default="{ row }">{{ row.created_by }}<br />{{ fmtTime(row.updated_at) }}</template>
            </el-table-column>
            <el-table-column label="操作" width="200" fixed="right">
              <template #default="{ row }">
                <el-button text type="primary" size="small" @click="openRule(row)">编辑</el-button>
                <el-button text :type="row.enabled ? 'warning' : 'success'" size="small" @click="toggleRule(row)">{{ row.enabled ? '停用' : '启用' }}</el-button>
                <el-button text size="small" @click="showHistory(row)">历史</el-button>
              </template>
            </el-table-column>
          </el-table>
        </el-card>
      </el-col>
    </el-row>

    <el-dialog v-model="positionDialog" :title="positionForm.id ? '编辑岗位' : '新增岗位'" width="480px">
      <el-form :model="positionForm" label-width="90px">
        <el-form-item label="岗位名称" required><el-input v-model="positionForm.name" /></el-form-item>
        <el-form-item label="岗位编码" required><el-input v-model="positionForm.code" :disabled="!!positionForm.id" placeholder="如 FDY" /></el-form-item>
        <el-form-item label="所属部门"><el-input v-model="positionForm.department" /></el-form-item>
        <el-form-item label="岗位描述"><el-input v-model="positionForm.description" type="textarea" :rows="3" /></el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="positionDialog = false">取消</el-button>
        <el-button type="primary" @click="savePosition">保存</el-button>
      </template>
    </el-dialog>

    <el-dialog v-model="ruleDialog" :title="ruleForm.id ? `编辑规则（保存后生成新版本 v${ruleForm.version + 1}）` : '新增规则'" width="720px" top="4vh">
      <el-form :model="ruleForm" label-width="150px" size="small">
        <el-form-item label="规则名称" required><el-input v-model="ruleForm.name" /></el-form-item>
        <el-divider content-position="left">硬性资格条件（不满足 / 待核实均不参与评分排序）</el-divider>
        <el-form-item label="最低学历">
          <el-select v-model="ruleForm.config.min_education" clearable placeholder="不限" style="width: 200px">
            <el-option v-for="e in educationOptions" :key="e" :label="e" :value="e" />
          </el-select>
        </el-form-item>
        <el-form-item label="可接受专业">
          <el-select v-model="ruleForm.config.accepted_majors" multiple filterable allow-create default-first-option placeholder="输入专业后回车，可多个；留空 = 不限" style="width: 100%" />
        </el-form-item>
        <el-form-item label="专业必须匹配"><el-switch v-model="ruleForm.config.major_match_required" /></el-form-item>
        <el-form-item label="年龄上限（周岁）"><el-input-number v-model="ruleForm.config.max_age" :min="0" :max="120" placeholder="不限" /></el-form-item>
        <el-form-item label="要求中共党员"><el-switch v-model="ruleForm.config.require_party_member" /></el-form-item>
        <el-form-item label="仅限应届毕业生"><el-switch v-model="ruleForm.config.fresh_only" /></el-form-item>
        <el-form-item label="非应届附加条件">
          <el-select v-model="ruleForm.config.non_fresh_requires" clearable placeholder="无" style="width: 280px">
            <el-option label="需上海户籍或有效上海居住证" value="shanghai_hukou_or_residence_permit" />
          </el-select>
        </el-form-item>
        <el-form-item label="最低工作经验(年)"><el-input-number v-model="ruleForm.config.min_work_years" :min="0" :max="50" /></el-form-item>
        <el-divider content-position="left">综合评分配置（总分 100，与硬性核验独立）</el-divider>
        <el-form-item label="学校层次分值">
          <div class="score-grid">
            <span v-for="t in schoolTierOptions" :key="t">{{ t }} <el-input-number v-model="ruleForm.config.scoring.school_tier[t]" :min="0" :max="40" size="small" style="width: 90px" /></span>
          </div>
        </el-form-item>
        <el-form-item label="学历分值">
          <div class="score-grid">
            <span v-for="e in ['博士', '硕士', '本科', '大专']" :key="e">{{ e }} <el-input-number v-model="ruleForm.config.scoring.education[e]" :min="0" :max="40" size="small" style="width: 90px" /></span>
          </div>
        </el-form-item>
        <el-form-item label="专业匹配加分"><el-input-number v-model="ruleForm.config.scoring.major_match" :min="0" :max="40" /></el-form-item>
        <el-form-item label="应届生加分"><el-input-number v-model="ruleForm.config.scoring.fresh_bonus" :min="0" :max="30" /></el-form-item>
        <el-form-item label="工作经验每年"><el-input-number v-model="ruleForm.config.scoring.work_years.per_year" :min="0" :max="10" /></el-form-item>
        <el-form-item label="工作经验上限分"><el-input-number v-model="ruleForm.config.scoring.work_years.max" :min="0" :max="40" /></el-form-item>
        <el-form-item label="相关经验加分"><el-input-number v-model="ruleForm.config.scoring.related_experience_bonus" :min="0" :max="30" /></el-form-item>
        <el-form-item label="修改说明"><el-input v-model="ruleForm.change_note" placeholder="记录本次修改原因，写入规则日志" /></el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="ruleDialog = false">取消</el-button>
        <el-button type="primary" @click="saveRule">保存（生成新版本）</el-button>
      </template>
    </el-dialog>

    <el-drawer v-model="historyDrawer" title="规则版本历史" size="480px">
      <el-timeline>
        <el-timeline-item v-for="h in history" :key="h.id" :timestamp="fmtTime(h.created_at)" placement="top">
          <el-card shadow="never">
            <p><b>v{{ h.version }}</b> — {{ h.name }}
              <el-tag size="small" :type="h.enabled ? 'success' : 'info'" style="margin-left: 6px">{{ h.enabled ? '启用' : '已被新版本替代/停用' }}</el-tag>
            </p>
            <p style="color: #909399; font-size: 12px">修改人：{{ h.created_by }}　{{ h.change_note }}</p>
            <p style="font-size: 12px">{{ ruleSummary(h.config) }}</p>
          </el-card>
        </el-timeline-item>
      </el-timeline>
    </el-drawer>
  </div>
</template>

<script setup lang="ts">
import { computed, onMounted, reactive, ref } from 'vue'
import { ElMessage } from 'element-plus'
import api from '../api'
import { educationOptions, schoolTierOptions } from '../display'

const positions = ref<any[]>([])
const rules = ref<any[]>([])
const currentPosition = ref<any>(null)
const positionDialog = ref(false)
const ruleDialog = ref(false)
const historyDrawer = ref(false)
const history = ref<any[]>([])

const positionForm = reactive<any>({ id: null, name: '', code: '', department: '', description: '' })
const ruleForm = reactive<any>({ id: null, version: 0, name: '', change_note: '', config: defaultConfig() })

const positionRules = computed(() => rules.value.filter((r) => r.position_id === currentPosition.value?.id))
const fmtTime = (t: string) => (t ? new Date(t).toLocaleString('zh-CN') : '—')

function defaultConfig() {
  return {
    min_education: '', accepted_majors: [] as string[], major_match_required: false,
    max_age: null as number | null, require_party_member: false, fresh_only: false,
    non_fresh_requires: '', min_work_years: 0,
    scoring: {
      school_tier: { '985': 20, '211': 15, '双一流': 12, '普通本科': 8, '其他': 4 } as Record<string, number>,
      education: { '博士': 25, '硕士': 18, '本科': 10, '大专': 4 } as Record<string, number>,
      major_match: 20, fresh_bonus: 10,
      work_years: { per_year: 2, max: 15 }, related_experience_bonus: 10,
    },
  }
}

function ruleSummary(c: any) {
  if (!c) return ''
  const parts: string[] = []
  if (c.min_education) parts.push(`学历≥${c.min_education}`)
  if (c.accepted_majors?.length) parts.push(`专业：${c.accepted_majors.join('/')}${c.major_match_required ? '（必须）' : ''}`)
  if (c.max_age) parts.push(`年龄<${c.max_age}`)
  if (c.require_party_member) parts.push('中共党员')
  if (c.fresh_only) parts.push('仅限应届')
  if (c.non_fresh_requires === 'shanghai_hukou_or_residence_permit') parts.push('非应届需沪籍/居住证')
  if (c.min_work_years) parts.push(`经验≥${c.min_work_years}年`)
  return parts.join('；') || '无硬性条件'
}

async function load() {
  const [p, r] = await Promise.all([api.get('/positions'), api.get('/rules')])
  positions.value = p.data
  rules.value = r.data
}

function onPickPosition(row: any) {
  if (row) currentPosition.value = row
}

function openPosition(row?: any) {
  Object.assign(positionForm, row ? { id: row.id, name: row.name, code: row.code, department: row.department, description: row.description } : { id: null, name: '', code: '', department: '', description: '' })
  positionDialog.value = true
}

async function savePosition() {
  if (!positionForm.name || !positionForm.code) {
    ElMessage.warning('请填写岗位名称和编码')
    return
  }
  if (positionForm.id) await api.put(`/positions/${positionForm.id}`, positionForm)
  else await api.post('/positions', positionForm)
  ElMessage.success('岗位已保存')
  positionDialog.value = false
  load()
}

async function togglePosition(row: any) {
  await api.put(`/positions/${row.id}/toggle`)
  load()
}

function openRule(row?: any) {
  if (row) {
    const c = { ...defaultConfig(), ...row.config, scoring: { ...defaultConfig().scoring, ...(row.config?.scoring || {}) } }
    ruleForm.id = row.id
    ruleForm.version = row.version
    ruleForm.name = row.name
    ruleForm.change_note = ''
    ruleForm.config = c
  } else {
    ruleForm.id = null
    ruleForm.version = 0
    ruleForm.name = `${currentPosition.value.name}筛选规则`
    ruleForm.change_note = ''
    ruleForm.config = defaultConfig()
  }
  ruleDialog.value = true
}

async function saveRule() {
  if (!ruleForm.name) {
    ElMessage.warning('请填写规则名称')
    return
  }
  const body = { position_id: currentPosition.value.id, name: ruleForm.name, config: ruleForm.config, enabled: true, change_note: ruleForm.change_note }
  if (ruleForm.id) await api.put(`/rules/${ruleForm.id}`, body)
  else await api.post('/rules', body)
  ElMessage.success('规则已保存，新筛选将使用最新版本')
  ruleDialog.value = false
  load()
}

async function toggleRule(row: any) {
  await api.put(`/rules/${row.id}/toggle`)
  load()
}

async function showHistory(row: any) {
  const { data } = await api.get(`/rules/${row.id}/history`)
  history.value = data
  historyDrawer.value = true
}

onMounted(async () => {
  await load()
  if (positions.value.length) currentPosition.value = positions.value[0]
})
</script>

<style scoped>
.title { font-size: 15px; font-weight: 600; }
.card-header { display: flex; justify-content: space-between; align-items: center; }
.score-grid { display: flex; flex-wrap: wrap; gap: 10px 16px; align-items: center; }
</style>
