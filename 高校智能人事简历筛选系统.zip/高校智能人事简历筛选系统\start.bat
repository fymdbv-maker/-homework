@echo off
chcp 65001 >nul
setlocal EnableDelayedExpansion
title 高校智能人事简历筛选系统 - 一键启动

cd /d "%~dp0"
set "ROOT=%~dp0"

echo ==========================================
echo   高校智能人事简历筛选系统 - 一键启动
echo ==========================================
echo.

REM ---------- 0. 关闭代理对本地服务的影响 ----------
set "no_proxy=*"
set "NO_PROXY=*"

REM ---------- 1. 检查 Python（跳过 WindowsApps 占位 stub，验证可真实运行）----------
set "PY="
for %%P in (
    "%LOCALAPPDATA%\Programs\Python\Python313\python.exe"
    "%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
    "%LOCALAPPDATA%\Programs\Python\Python311\python.exe"
    "%LOCALAPPDATA%\Programs\Python\Python310\python.exe"
) do (
    if not defined PY if exist %%~P (
        %%~P -c "import sys" >nul 2>nul && set "PY=%%~fP"
    )
)
if not defined PY (
    python -c "import sys" >nul 2>nul && set "PY=python"
)
if not defined PY (
    echo [错误] 未找到可用的 Python。请先安装 Python 3.10+ 并勾选 "Add to PATH"。
    echo        下载地址: https://www.python.org/downloads/
    pause
    exit /b 1
)
echo [OK] Python: %PY%

REM ---------- 2. 检查 Node.js ----------
set "NODE_OK="
node --version >nul 2>nul && set "NODE_OK=1"
if not defined NODE_OK (
    for /d %%D in ("%LOCALAPPDATA%\Microsoft\WinGet\Packages\OpenJS.NodeJS*") do (
        if exist "%%~fD" (
            for /d %%N in ("%%~fD\node-*-win-x64") do set "PATH=%%~fN;!PATH!"
        )
    )
    node --version >nul 2>nul && set "NODE_OK=1"
)
if not defined NODE_OK (
    echo [错误] 未找到 Node.js。请先安装 Node.js 18+ ^(LTS 版本^)。
    echo        下载地址: https://nodejs.org/
    pause
    exit /b 1
)
echo [OK] Node.js 已找到

REM ---------- 3. 准备 .env ----------
if not exist "%ROOT%.env" (
    copy "%ROOT%.env.example" "%ROOT%.env" >nul
    echo [OK] 已从 .env.example 生成 .env
)

REM ---------- 4. 安装后端依赖 ----------
echo.
echo [1/4] 检查后端依赖...
"%PY%" -c "import fastapi, uvicorn, sqlalchemy" >nul 2>nul
if errorlevel 1 (
    echo      正在安装后端依赖（使用清华镜像）...
    "%PY%" -m pip install -r "%ROOT%backend\requirements.txt" -i https://pypi.tuna.tsinghua.edu.cn/simple
    if errorlevel 1 (
        echo [错误] 后端依赖安装失败，请检查网络后重试。
        pause
        exit /b 1
    )
)
echo [OK] 后端依赖就绪

REM ---------- 5. 初始化数据库 ----------
echo [2/4] 初始化数据库与演示数据...
"%PY%" "%ROOT%backend\init_db.py"
if errorlevel 1 (
    echo [错误] 数据库初始化失败。
    pause
    exit /b 1
)

REM ---------- 6. 安装前端依赖 ----------
echo [3/4] 检查前端依赖...
if not exist "%ROOT%frontend\node_modules" (
    echo      正在安装前端依赖（使用 npmmirror 镜像，首次较慢）...
    pushd "%ROOT%frontend"
    call npm install --registry=https://registry.npmmirror.com
    if errorlevel 1 (
        echo [错误] 前端依赖安装失败，请检查网络后重试。
        popd
        pause
        exit /b 1
    )
    popd
)
echo [OK] 前端依赖就绪

REM ---------- 7. 启动服务 ----------
echo [4/4] 启动后端与前端服务...
start "HR-后端 API (8000)" cmd /k "cd /d "%ROOT%backend" && set no_proxy=* && "%PY%" -m uvicorn app.main:app --host 127.0.0.1 --port 8000"
timeout /t 3 /nobreak >nul
start "HR-前端 (5173)" cmd /k "cd /d "%ROOT%frontend" && npm run dev -- --host 127.0.0.1 --port 5173"

echo.
echo ==========================================
echo   启动完成！请稍候几秒后访问：
echo.
echo   前端页面:   http://localhost:5173
echo   后端 API:   http://localhost:8000
echo   API 文档:   http://localhost:8000/docs
echo.
echo   演示账号:
echo     管理员    admin  / admin123
echo     人事专员  hr     / hr123456
echo     只读用户  viewer / view123
echo.
echo   关闭本窗口不会停止服务；
echo   关闭 "HR-后端" 和 "HR-前端" 两个窗口即停止服务。
echo ==========================================
pause
