<template>
  <div>
    <el-card shadow="never">
      <template #header><span class="title">智能筛选与评分</span></template>
      <el-alert type="info" :closable="false" style="margin-bottom: 12px"
        title="说明：硬性资格核验（学历 / 政治面貌 / 年龄 / 户籍等）与综合评分相互独立；无法识别的信息显示为“待核实”，不会被当作不符合；AI 建议仅供参考，不作最终淘汰决定。" />

      <el-form inline>
        <el-form-item label="招聘岗位">
          <el-select v-model="positionId" placeholder="选择岗位" style="width: 200px" @change="onPositionChange">
            <el-option v-for="p in positions" :key="p.id" :label="p.name" :value="p.id" />
          </el-select>
        </el-form-item>
        <el-form-item label="筛选规则">
          <el-select v-model="ruleId" placeholder="选择规则" style="width: 260px">
            <el-option v-for="r in positionRules" :key="r.id" :label="`${r.name} v${r.version}${r.enabled ? '' : '（已停用）'}`" :value="r.id" :disabled="!r.enabled" />
          </el-select>
        </el-form-item>
        <el-form-item label="简历范围">
          <el-select v-model="resumeIds" multiple collapse-tags collapse-tags-tooltip placeholder="不选 = 全部未按此规则筛选过的简历" style="width: 300px" filterable>
            <el-option v-for="r in resumes" :key="r.id" :label="`#${r.id} ${r.name || '待核实'}（${r.education || '待核实'}）`" :value="r.id" />
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-checkbox v-model="rerun">对已筛选过的简历重新运行</el-checkbox>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" :loading="running" :disabled="!ruleId" @click="run">运行筛选</el-button>
        </el-form-item>
      </el-form>

      <el-descriptions v-if="activeRule" :column="2" border size="small" style="margin-bottom: 12px" title="当前规则硬性条件">
        <el-descriptions-item label="最低学历">{{ activeRule.config.min_education || '不限' }}</el-descriptions-item>
        <el-descriptions-item label="专业要求">
          {{ (activeRule.config.accepted_majors || []).join('、') || '不限' }}
          <el-tag v-if="activeRule.config.major_match_required" size="small" type="danger" style="margin-left:4px">必须匹配</el-tag>
        </el-descriptions-item>
        <el-descriptions-item label="年龄上限">{{ activeRule.config.max_age ? activeRule.config.max_age + ' 周岁以下' : '不限' }}</el-descriptions-item>
        <el-descriptions-item label="政治面貌">{{ activeRule.config.require_party_member ? '中共党员（含预备党员）' : '不限' }}</el-descriptions-item>
        <el-descriptions-item label="应届要求">{{ activeRule.config.fresh_only ? '仅限应届毕业生' : '不限' }}</el-descriptions-item>
        <el-descriptions-item label="非应届附加">{{ activeRule.config.non_fresh_requires === 'shanghai_hukou_or_residence_permit' ? '需上海户籍或有效上海居住证' : '无' }}</el-descriptions-item>
      </el-descriptions>

      <el-table :data="results" v-loading="running">
        <el-table-column label="姓名" width="100">
          <template #default="{ row }">{{ resumeName(row.resume_id) }}</template>
        </el-table-column>
        <el-table-column prop="position_name" label="岗位" width="110" />
        <el-table-column label="硬性核验" min-width="220">
          <template #default="{ row }">
            <el-tag v-for="(c, i) in row.hard_checks" :key="i" size="small" style="margin: 2px" :type="checkStatusMap[c.status]?.type">
              {{ c.item }}：{{ checkStatusMap[c.status]?.label }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="核验结论" width="100">
          <template #default="{ row }"><el-tag size="small" :type="qualMap[row.qualification]?.type">{{ qualMap[row.qualification]?.label }}</el-tag></template>
        </el-table-column>
        <el-table-column label="综合评分" width="110" sortable prop="score">
          <template #default="{ row }">
            <el-popover width="380" trigger="hover">
              <template #reference><span class="score">{{ row.score }}</span></template>
              <el-table :data="row.score_breakdown" size="small">
                <el-table-column prop="item" label="评分项" width="110" />
                <el-table-column prop="points" label="得分" width="60" />
                <el-table-column prop="max" label="满分" width="60" />
                <el-table-column prop="reason" label="说明" show-overflow-tooltip />
              </el-table>
            </el-popover>
          </template>
        </el-table-column>
        <el-table-column prop="suggestion" label="AI 辅助建议" min-width="200" show-overflow-tooltip />
        <el-table-column label="操作" width="80">
          <template #default="{ row }"><el-button text type="primary" size="small" @click="$router.push(`/resumes/${row.resume_id}`)">简历详情</el-button></template>
        </el-table-column>
      </el-table>
      <el-empty v-if="!results.length && ran" description="没有新的简历被处理（可能均已按此规则筛选过，可勾选“重新运行”）" />
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'
import { ElMessage } from 'element-plus'
import api from '../api'
import { qualMap, checkStatusMap } from '../display'

const positions = ref<any[]>([])
const rules = ref<any[]>([])
const resumes = ref<any[]>([])
const positionId = ref<number | null>(null)
const ruleId = ref<number | null>(null)
const resumeIds = ref<number[]>([])
const rerun = ref(false)
const running = ref(false)
const ran = ref(false)
const results = ref<any[]>([])

const positionRules = computed(() => rules.value.filter((r) => r.position_id === positionId.value))
const activeRule = computed(() => rules.value.find((r) => r.id === ruleId.value))
const resumeMap = computed(() => Object.fromEntries(resumes.value.map((r) => [r.id, r])))
const resumeName = (id: number) => resumeMap.value[id]?.name || '待核实'

function onPositionChange() {
  ruleId.value = positionRules.value.find((r) => r.enabled)?.id ?? null
}

async function run() {
  if (!ruleId.value) return
  running.value = true
  try {
    const { data } = await api.post('/screening/run', {
      rule_id: ruleId.value,
      resume_ids: resumeIds.value.length ? resumeIds.value : null,
      rerun: rerun.value,
    })
    results.value = data
    ran.value = true
    ElMessage.success(`筛选完成，共处理 ${data.length} 份简历`)
  } finally {
    running.value = false
  }
}

onMounted(async () => {
  const [p, r, rs] = await Promise.all([
    api.get('/positions'),
    api.get('/rules'),
    api.get('/resumes', { params: { page: 1, page_size: 100 } }),
  ])
  positions.value = p.data
  rules.value = r.data
  resumes.value = rs.data.items
  if (positions.value.length) {
    positionId.value = positions.value[0].id
    onPositionChange()
  }
})
</script>

<style scoped>
.title { font-size: 16px; font-weight: 600; }
.score { color: #1f6feb; font-weight: 600; cursor: pointer; }
</style>
