<template>
  <div>
    <el-card shadow="never">
      <div class="toolbar">
        <el-input v-model="query.keyword" placeholder="搜索姓名 / 学校 / 专业 / 岗位" clearable style="width: 240px" @change="load(1)" />
        <el-select v-model="query.education" placeholder="学历" clearable style="width: 110px" @change="load(1)">
          <el-option v-for="e in educationOptions" :key="e" :label="e" :value="e" />
        </el-select>
        <el-select v-model="query.school_tier" placeholder="学校层次" clearable style="width: 120px" @change="load(1)">
          <el-option v-for="t in schoolTierOptions" :key="t" :label="t" :value="t" />
        </el-select>
        <el-select v-model="query.is_fresh" placeholder="应届身份" clearable style="width: 120px" @change="load(1)">
          <el-option label="应届毕业生" value="fresh" /><el-option label="非应届" value="not_fresh" /><el-option label="待核实" value="unknown" />
        </el-select>
        <el-select v-model="query.parse_status" placeholder="解析状态" clearable style="width: 120px" @change="load(1)">
          <el-option v-for="(v, k) in parseStatusMap" :key="k" :label="v.label" :value="k" />
        </el-select>
        <el-select v-model="query.source" placeholder="来源" clearable style="width: 100px" @change="load(1)">
          <el-option label="上传" value="upload" /><el-option label="邮箱" value="email" />
        </el-select>
        <el-button type="primary" :icon="Search" @click="load(1)">查询</el-button>
        <div style="flex: 1" />
        <el-upload :show-file-list="false" multiple :auto-upload="false" :on-change="onPick" accept=".pdf,.docx,.doc,.txt,.jpg,.jpeg,.png,.bmp,.webp">
          <el-button type="success" :icon="UploadFilled" :loading="uploading">上传简历</el-button>
        </el-upload>
      </div>

      <el-table :data="rows" v-loading="loading" style="margin-top: 12px">
        <el-table-column prop="id" label="ID" width="60" />
        <el-table-column label="姓名" width="100">
          <template #default="{ row }">
            <el-link type="primary" @click="$router.push(`/resumes/${row.id}`)">{{ show(row.name) }}</el-link>
          </template>
        </el-table-column>
        <el-table-column label="应聘岗位" min-width="110" show-overflow-tooltip>
          <template #default="{ row }">{{ show(row.target_position) }}</template>
        </el-table-column>
        <el-table-column label="最高学历" width="80">
          <template #default="{ row }">{{ show(row.education) }}</template>
        </el-table-column>
        <el-table-column label="毕业院校" min-width="130" show-overflow-tooltip>
          <template #default="{ row }">
            {{ show(row.school) }}
            <el-tag v-if="row.school_tier" size="small" style="margin-left:4px">{{ row.school_tier }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="专业" min-width="110" show-overflow-tooltip>
          <template #default="{ row }">{{ show(row.major) }}</template>
        </el-table-column>
        <el-table-column label="毕业时间" width="100">
          <template #default="{ row }">{{ show(row.graduation_date) }}</template>
        </el-table-column>
        <el-table-column label="工作经验" width="90">
          <template #default="{ row }">{{ row.work_years === null ? UNKNOWN : row.work_years + ' 年' }}</template>
        </el-table-column>
        <el-table-column label="应届" width="90">
          <template #default="{ row }">
            <el-tag size="small" :type="freshMap[row.is_fresh]?.type">{{ freshMap[row.is_fresh]?.label }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="解析状态" width="90">
          <template #default="{ row }">
            <el-tag size="small" :type="parseStatusMap[row.parse_status]?.type">{{ parseStatusMap[row.parse_status]?.label }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="150" fixed="right">
          <template #default="{ row }">
            <el-button text type="primary" size="small" @click="$router.push(`/resumes/${row.id}`)">详情</el-button>
            <el-popconfirm title="确定删除该简历及其筛选结果？" @confirm="onDelete(row)">
              <template #reference><el-button text type="danger" size="small">删除</el-button></template>
            </el-popconfirm>
          </template>
        </el-table-column>
      </el-table>

      <el-pagination
        style="margin-top: 12px; justify-content: flex-end"
        background layout="total, sizes, prev, pager, next" :total="total"
        v-model:current-page="query.page" v-model:page-size="query.page_size"
        :page-sizes="[10, 20, 50]" @current-change="load()" @size-change="load(1)"
      />
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { onMounted, reactive, ref } from 'vue'
import { Search, UploadFilled } from '@element-plus/icons-vue'
import { ElMessage } from 'element-plus'
import type { UploadFile } from 'element-plus'
import api from '../api'
import { show, UNKNOWN, educationOptions, schoolTierOptions, freshMap, parseStatusMap } from '../display'

const loading = ref(false)
const uploading = ref(false)
const rows = ref<any[]>([])
const total = ref(0)
const query = reactive({ page: 1, page_size: 10, keyword: '', education: '', is_fresh: '', parse_status: '', school_tier: '', source: '' })

async function load(page?: number) {
  if (page) query.page = page
  loading.value = true
  try {
    const { data } = await api.get('/resumes', { params: query })
    rows.value = data.items
    total.value = data.total
  } finally {
    loading.value = false
  }
}

async function onPick(file: UploadFile) {
  if (!file.raw) return
  uploading.value = true
  try {
    const fd = new FormData()
    fd.append('files', file.raw)
    const { data } = await api.post('/resumes/upload', fd)
    if (data.length === 0) ElMessage.warning(`${file.name}：与已有简历重复，已跳过`)
    else ElMessage.success(`已上传并解析：${file.name}`)
    load(1)
  } finally {
    uploading.value = false
  }
}

async function onDelete(row: any) {
  await api.delete(`/resumes/${row.id}`)
  ElMessage.success('已删除')
  load()
}

onMounted(() => load())
</script>

<style scoped>
.toolbar { display: flex; gap: 10px; flex-wrap: wrap; align-items: center; }
</style>
