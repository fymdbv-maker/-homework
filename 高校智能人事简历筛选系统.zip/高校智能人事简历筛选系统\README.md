# 高校智能人事简历筛选系统

面向高校人事处的简历智能筛选 Web 系统。支持简历上传解析（PDF/DOCX/DOC/TXT/图片）、岗位硬性资格核验（辅导员党员/硕士/40 岁以下、非应届上海户籍或居住证等）、综合评分、人工审核工作台、邮箱 IMAP 简历导入、规则版本管理与操作审计。

**硬性资格核验与综合评分相互独立**；无法识别的字段显示"待核实"，不会被当作不符合条件；政治面貌、年龄、户籍等敏感条件仅作独立核验项，不进入默认综合评分；AI 只提供可解释建议，不作最终淘汰决定。

## 技术栈

| 层 | 技术 |
| --- | --- |
| 前端 | Vue 3 + TypeScript + Vite + Element Plus |
| 后端 | Python 3.10+ + FastAPI + SQLAlchemy |
| 数据库 | SQLite（默认）/ PostgreSQL（预留配置） |
| 认证 | JWT + PBKDF2 密码哈希；凭据 Fernet 加密存储 |

## 快速开始（Windows）

前置要求：Python 3.10+、Node.js 18+。

**方式一：一键启动**

双击运行 `start.bat`。脚本会自动：检测 Python/Node → 生成 `.env` → 安装依赖（国内镜像）→ 初始化 SQLite 数据库和演示数据 → 启动后端 (8000) 与前端 (5173)。

**方式二：手动启动**

```bat
:: 后端
cd backend
python -m venv .venv && .venv\Scripts\activate
pip install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple
python init_db.py
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000

:: 前端（新开一个终端）
cd frontend
npm install --registry=https://registry.npmmirror.com
npm run dev
```

## 访问地址与演示账号

| 入口 | 地址 |
| --- | --- |
| 前端页面 | http://localhost:5173 |
| 后端 API | http://localhost:8000 |
| Swagger 文档 | http://localhost:8000/docs |

| 角色 | 账号 | 密码 |
| --- | --- | --- |
| 管理员 | admin | admin123 |
| 人事专员 | hr | hr123456 |
| 只读用户 | viewer | view123 |

系统预置 5 份演示简历与 2 个岗位规则（辅导员、专任教师），登录后即可直接体验筛选与审核。

## 项目结构

```
├── start.bat               # Windows 一键启动脚本
├── .env.example            # 环境变量模板（复制为 .env 使用）
├── backend/
│   ├── app/
│   │   ├── main.py         # FastAPI 入口、CORS
│   │   ├── config.py       # 配置读取（全部来自环境变量）
│   │   ├── database.py     # SQLAlchemy 引擎/会话
│   │   ├── models.py       # 用户/岗位/规则/简历/筛选结果/日志模型
│   │   ├── schemas.py      # Pydantic 模型
│   │   ├── security.py     # PBKDF2 哈希、JWT、Fernet 加密
│   │   ├── deps.py         # 依赖注入、RBAC、审计
│   │   ├── routers/        # auth/dashboard/resumes/screening/rules/email_import/system
│   │   └── services/       # resume_parser / screening_engine / email_service
│   ├── init_db.py          # 建表 + 演示数据（幂等，可重复执行）
│   └── requirements.txt
└── frontend/
    └── src/
        ├── views/          # 登录/布局/仪表盘/简历列表/简历详情/智能筛选/工作台/邮箱导入/规则管理/系统设置
        ├── router.ts api.ts display.ts
        └── main.ts App.vue
```

## 功能清单

- **登录与仪表盘**：JWT 登录，简历总数/待解析/符合条件/待审核等实时统计，最近导入与筛选结果。
- **简历管理**：多格式上传（PDF/DOCX/DOC/TXT/JPG/PNG/BMP/WEBP）、自动解析、重复文件识别、搜索/筛选/分页、详情（字段+识别依据+原始文本+筛选记录）、人工修正、删除、重新解析、原始文件下载（需登录）。
- **智能筛选**：按岗位规则运行；硬性核验输出 满足/不满足/待核实 及证据；综合评分独立计算并可查看明细；AI 建议仅供参考。
- **人事筛选工作台**：岗位/学历/学校层次/应届/专业匹配/审核状态多维度筛选、快捷筛选、多选批量审核、单人审核备注、CSV 导出。
- **邮箱简历导入**：IMAP 配置（页面或 .env）、手动同步、附件自动入库、重复附件识别、导入日志；未配置时明确显示演示模式。
- **岗位规则管理**：岗位与规则的可视化增改、启用/停用；规则每次修改生成新版本并保留历史。
- **系统设置与审计**：用户角色管理（admin/hr/viewer）、操作日志、系统参数（敏感值脱敏）、模型配置状态；密码/密钥一律不落源码。

## 安全与合规设计

- 密码 PBKDF2 哈希；邮箱凭据 Fernet 加密；所有密钥从 `.env` 读取，仓库不含任何真实密钥。
- 简历原始文件仅登录用户可访问；删除简历同时删除文件与筛选结果。
- 政治面貌/年龄/户籍等敏感项只做独立核验，不纳入默认评分；未知信息一律"待核实"。

## 文档

- [docs/需求文档.md](docs/需求文档.md)
- [docs/系统设计.md](docs/系统设计.md)
- [docs/API文档.md](docs/API文档.md)
- [docs/测试报告模板.md](docs/测试报告模板.md)
- [docs/部署说明.md](docs/部署说明.md)

## 生产部署提示

1. `.env` 中修改 `SECRET_KEY` 为随机长字符串，显式设置 `CREDENTIAL_KEY`。
2. 切换 PostgreSQL：安装 `psycopg2-binary`，设置 `DATABASE_URL=postgresql+psycopg2://user:pass@host:5432/hr_screening`。
3. 前端 `npm run build` 产物可用任意静态服务器托管，生产环境建议由 Nginx 反向代理 `/api` 到后端。
4. 详见 [docs/部署说明.md](docs/部署说明.md)。
